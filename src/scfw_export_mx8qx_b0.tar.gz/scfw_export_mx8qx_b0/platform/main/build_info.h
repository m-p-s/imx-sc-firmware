#ifndef BUILD_INFO_H
#define BUILD_INFO_H

#define SCFW_BRANCH imx_scfw_2020q2
#define SCFW_BUILD 4612UL
#define SCFW_COMMIT 0x732e719aUL
#define SCFW_DATE "Jun 19 2020"
#define SCFW_DATE2 Jun_19_2020
#define SCFW_TIME "19:00:48"

#endif
