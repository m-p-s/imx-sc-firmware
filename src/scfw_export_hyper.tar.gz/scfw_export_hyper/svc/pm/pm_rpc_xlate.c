/*
 * Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2017-2020 NXP
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*!
 * File containing hypervisor RPC functions for the PM service.
 *
 * @addtogroup PM_SVC
 * @{
 */

/* Includes */

#include "main/types.h"
#include "svc/pm/pm_api.h"
#include "../../main/rpc.h"
#include "svc/pm/pm_rpc.h"

/* Local Defines */

/* Local Types */

/*--------------------------------------------------------------------------*/
/* Translate and forward RPC call                                           */
/*--------------------------------------------------------------------------*/
void pm_xlate(sc_ipc_t ipc, sc_rpc_msg_t *msg)
{
    uint8_t func = RPC_FUNC(msg);
    sc_err_t err = SC_ERR_NONE;

    switch (func)
    {
        case PM_FUNC_UNKNOWN :
            {
                RPC_SIZE(msg) = 1;
                RPC_R8(msg) = SC_ERR_NOTFOUND;
            }
            break;
        case PM_FUNC_SET_SYS_POWER_MODE :
            {
                sc_err_t result;
                sc_pm_power_mode_t mode = ((sc_pm_power_mode_t) RPC_U8(msg, 0U));

                result = sc_pm_set_sys_power_mode(ipc, mode);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case PM_FUNC_SET_PARTITION_POWER_MODE :
            {
                sc_err_t result;
                sc_rm_pt_t pt = ((sc_rm_pt_t) RPC_U8(msg, 0U));
                sc_pm_power_mode_t mode = ((sc_pm_power_mode_t) RPC_U8(msg, 1U));

                V2P_PT(ipc, &pt);

                result = sc_pm_set_partition_power_mode(ipc, pt, mode);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case PM_FUNC_GET_SYS_POWER_MODE :
            {
                sc_err_t result;
                sc_rm_pt_t pt = ((sc_rm_pt_t) RPC_U8(msg, 0U));
                sc_pm_power_mode_t mode = ((sc_pm_power_mode_t) 0U);

                V2P_PT(ipc, &pt);

                result = sc_pm_get_sys_power_mode(ipc, pt, &mode);

                RPC_R8(msg) = U8(result);
                RPC_U8(msg, 0U) = U8(mode);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case PM_FUNC_PARTITION_WAKE :
            {
                sc_err_t result;
                sc_rm_pt_t pt = ((sc_rm_pt_t) RPC_U8(msg, 0U));

                V2P_PT(ipc, &pt);

                result = sc_pm_partition_wake(ipc, pt);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case PM_FUNC_SET_RESOURCE_POWER_MODE :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 0U));
                sc_pm_power_mode_t mode = ((sc_pm_power_mode_t) RPC_U8(msg, 2U));

                V2P_RESOURCE(ipc, &resource);

                result = sc_pm_set_resource_power_mode(ipc, resource, mode);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case PM_FUNC_SET_RESOURCE_POWER_MODE_ALL :
            {
                sc_err_t result;
                sc_rm_pt_t pt = ((sc_rm_pt_t) RPC_U8(msg, 2U));
                sc_pm_power_mode_t mode = ((sc_pm_power_mode_t) RPC_U8(msg, 3U));
                sc_rsrc_t exclude = ((sc_rsrc_t) RPC_U16(msg, 0U));

                V2P_PT(ipc, &pt);
                V2P_RESOURCE(ipc, &exclude);

                result = sc_pm_set_resource_power_mode_all(ipc, pt, mode, exclude);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case PM_FUNC_GET_RESOURCE_POWER_MODE :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 0U));
                sc_pm_power_mode_t mode = ((sc_pm_power_mode_t) 0U);

                V2P_RESOURCE(ipc, &resource);

                result = sc_pm_get_resource_power_mode(ipc, resource, &mode);

                RPC_R8(msg) = U8(result);
                RPC_U8(msg, 0U) = U8(mode);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case PM_FUNC_REQ_LOW_POWER_MODE :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 0U));
                sc_pm_power_mode_t mode = ((sc_pm_power_mode_t) RPC_U8(msg, 2U));

                V2P_RESOURCE(ipc, &resource);

                result = sc_pm_req_low_power_mode(ipc, resource, mode);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case PM_FUNC_REQ_CPU_LOW_POWER_MODE :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 0U));
                sc_pm_power_mode_t mode = ((sc_pm_power_mode_t) RPC_U8(msg, 2U));
                sc_pm_wake_src_t wake_src = ((sc_pm_wake_src_t) RPC_U8(msg, 3U));

                V2P_RESOURCE(ipc, &resource);

                result = sc_pm_req_cpu_low_power_mode(ipc, resource, mode, wake_src);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case PM_FUNC_SET_CPU_RESUME_ADDR :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 8U));
                sc_faddr_t address = ((sc_faddr_t) RPC_U64(msg, 0U));

                V2P_RESOURCE(ipc, &resource);
                V2P_ADDR(ipc, &address);

                result = sc_pm_set_cpu_resume_addr(ipc, resource, address);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case PM_FUNC_SET_CPU_RESUME :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 8U));
                sc_bool_t isPrimary = U2B(RPC_U8(msg, 10U));
                sc_faddr_t address = ((sc_faddr_t) RPC_U64(msg, 0U));

                V2P_RESOURCE(ipc, &resource);
                V2P_ADDR(ipc, &address);

                result = sc_pm_set_cpu_resume(ipc, resource, isPrimary, address);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case PM_FUNC_REQ_SYS_IF_POWER_MODE :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 0U));
                sc_pm_sys_if_t sys_if = ((sc_pm_sys_if_t) RPC_U8(msg, 2U));
                sc_pm_power_mode_t hpm = ((sc_pm_power_mode_t) RPC_U8(msg, 3U));
                sc_pm_power_mode_t lpm = ((sc_pm_power_mode_t) RPC_U8(msg, 4U));

                V2P_RESOURCE(ipc, &resource);

                result = sc_pm_req_sys_if_power_mode(ipc, resource, sys_if, hpm, lpm);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case PM_FUNC_SET_CLOCK_RATE :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 4U));
                sc_pm_clk_t clk = ((sc_pm_clk_t) RPC_U8(msg, 6U));
                sc_pm_clock_rate_t rate = ((sc_pm_clock_rate_t) RPC_U32(msg, 0U));

                V2P_RESOURCE(ipc, &resource);

                result = sc_pm_set_clock_rate(ipc, resource, clk, &rate);

                RPC_R8(msg) = U8(result);
                RPC_U32(msg, 0U) = U32(rate);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case PM_FUNC_GET_CLOCK_RATE :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 0U));
                sc_pm_clk_t clk = ((sc_pm_clk_t) RPC_U8(msg, 2U));
                sc_pm_clock_rate_t rate = ((sc_pm_clock_rate_t) 0U);

                V2P_RESOURCE(ipc, &resource);

                result = sc_pm_get_clock_rate(ipc, resource, clk, &rate);

                RPC_R8(msg) = U8(result);
                RPC_U32(msg, 0U) = U32(rate);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case PM_FUNC_CLOCK_ENABLE :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 0U));
                sc_pm_clk_t clk = ((sc_pm_clk_t) RPC_U8(msg, 2U));
                sc_bool_t enable = U2B(RPC_U8(msg, 3U));
                sc_bool_t autog = U2B(RPC_U8(msg, 4U));

                V2P_RESOURCE(ipc, &resource);

                result = sc_pm_clock_enable(ipc, resource, clk, enable, autog);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case PM_FUNC_SET_CLOCK_PARENT :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 0U));
                sc_pm_clk_t clk = ((sc_pm_clk_t) RPC_U8(msg, 2U));
                sc_pm_clk_parent_t parent = ((sc_pm_clk_parent_t) RPC_U8(msg, 3U));

                V2P_RESOURCE(ipc, &resource);

                result = sc_pm_set_clock_parent(ipc, resource, clk, parent);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case PM_FUNC_GET_CLOCK_PARENT :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 0U));
                sc_pm_clk_t clk = ((sc_pm_clk_t) RPC_U8(msg, 2U));
                sc_pm_clk_parent_t parent = ((sc_pm_clk_parent_t) 0U);

                V2P_RESOURCE(ipc, &resource);

                result = sc_pm_get_clock_parent(ipc, resource, clk, &parent);

                RPC_R8(msg) = U8(result);
                RPC_U8(msg, 0U) = U8(parent);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case PM_FUNC_RESET :
            {
                sc_err_t result;
                sc_pm_reset_type_t type = ((sc_pm_reset_type_t) RPC_U8(msg, 0U));

                result = sc_pm_reset(ipc, type);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case PM_FUNC_RESET_REASON :
            {
                sc_err_t result;
                sc_pm_reset_reason_t reason = ((sc_pm_reset_reason_t) 0U);

                result = sc_pm_reset_reason(ipc, &reason);

                RPC_R8(msg) = U8(result);
                RPC_U8(msg, 0U) = U8(reason);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case PM_FUNC_GET_RESET_PART :
            {
                sc_err_t result;
                sc_rm_pt_t pt = ((sc_rm_pt_t) 0U);

                result = sc_pm_get_reset_part(ipc, &pt);

                P2V_PT(ipc, &pt);

                RPC_R8(msg) = U8(result);
                RPC_U8(msg, 0U) = U8(pt);
                RPC_SIZE(msg) = 2U;
            }
            break;
        case PM_FUNC_BOOT :
            {
                sc_err_t result;
                sc_rm_pt_t pt = ((sc_rm_pt_t) RPC_U8(msg, 14U));
                sc_rsrc_t resource_cpu = ((sc_rsrc_t) RPC_U16(msg, 8U));
                sc_faddr_t boot_addr = ((sc_faddr_t) RPC_U64(msg, 0U));
                sc_rsrc_t resource_mu = ((sc_rsrc_t) RPC_U16(msg, 10U));
                sc_rsrc_t resource_dev = ((sc_rsrc_t) RPC_U16(msg, 12U));

                V2P_PT(ipc, &pt);
                V2P_RESOURCE(ipc, &resource_cpu);
                V2P_ADDR(ipc, &boot_addr);
                V2P_RESOURCE(ipc, &resource_mu);
                V2P_RESOURCE(ipc, &resource_dev);

                result = sc_pm_boot(ipc, pt, resource_cpu, boot_addr, resource_mu, resource_dev);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case PM_FUNC_SET_BOOT_PARM :
            {
                sc_err_t result;
                sc_rsrc_t resource_cpu = ((sc_rsrc_t) RPC_U16(msg, 8U));
                sc_faddr_t boot_addr = ((sc_faddr_t) RPC_U64(msg, 0U));
                sc_rsrc_t resource_mu = ((sc_rsrc_t) RPC_U16(msg, 10U));
                sc_rsrc_t resource_dev = ((sc_rsrc_t) RPC_U16(msg, 12U));

                V2P_RESOURCE(ipc, &resource_cpu);
                V2P_ADDR(ipc, &boot_addr);
                V2P_RESOURCE(ipc, &resource_mu);
                V2P_RESOURCE(ipc, &resource_dev);

                result = sc_pm_set_boot_parm(ipc, resource_cpu, boot_addr, resource_mu, resource_dev);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case PM_FUNC_REBOOT :
            {
                sc_pm_reset_type_t type = ((sc_pm_reset_type_t) RPC_U8(msg, 0U));

                sc_pm_reboot(ipc, type);

                RPC_SIZE(msg) = 0U;
            }
            break;
        case PM_FUNC_REBOOT_PARTITION :
            {
                sc_err_t result;
                sc_rm_pt_t pt = ((sc_rm_pt_t) RPC_U8(msg, 0U));
                sc_pm_reset_type_t type = ((sc_pm_reset_type_t) RPC_U8(msg, 1U));

                V2P_PT(ipc, &pt);

                result = sc_pm_reboot_partition(ipc, pt, type);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case PM_FUNC_REBOOT_CONTINUE :
            {
                sc_err_t result;
                sc_rm_pt_t pt = ((sc_rm_pt_t) RPC_U8(msg, 0U));

                V2P_PT(ipc, &pt);

                result = sc_pm_reboot_continue(ipc, pt);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case PM_FUNC_CPU_START :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 8U));
                sc_bool_t enable = U2B(RPC_U8(msg, 10U));
                sc_faddr_t address = ((sc_faddr_t) RPC_U64(msg, 0U));

                V2P_RESOURCE(ipc, &resource);
                V2P_ADDR(ipc, &address);

                result = sc_pm_cpu_start(ipc, resource, enable, address);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case PM_FUNC_CPU_RESET :
            {
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 8U));
                sc_faddr_t address = ((sc_faddr_t) RPC_U64(msg, 0U));

                V2P_RESOURCE(ipc, &resource);
                V2P_ADDR(ipc, &address);

                sc_pm_cpu_reset(ipc, resource, address);

                RPC_SIZE(msg) = 0U;
            }
            break;
        case PM_FUNC_RESOURCE_RESET :
            {
                sc_err_t result;
                sc_rsrc_t resource = ((sc_rsrc_t) RPC_U16(msg, 0U));

                V2P_RESOURCE(ipc, &resource);

                result = sc_pm_resource_reset(ipc, resource);

                RPC_R8(msg) = U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        case PM_FUNC_IS_PARTITION_STARTED :
            {
                sc_bool_t result;
                sc_rm_pt_t pt = ((sc_rm_pt_t) RPC_U8(msg, 0U));

                V2P_PT(ipc, &pt);

                result = sc_pm_is_partition_started(ipc, pt);

                RPC_R8(msg) = B2U8(result);
                RPC_SIZE(msg) = 1U;
            }
            break;
        default :
            {
                RPC_SIZE(msg) = 1;
                RPC_R8(msg) = SC_ERR_NOTFOUND;
            }
            break;
    }

    RPC_VER(msg) = SC_RPC_VERSION;
    RPC_SVC(msg) = SC_RPC_SVC_RETURN;
}

/**@}*/

