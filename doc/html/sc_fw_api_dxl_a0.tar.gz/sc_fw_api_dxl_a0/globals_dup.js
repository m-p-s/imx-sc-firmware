var globals_dup =
[
    [ "c", "globals.html", null ],
    [ "i", "globals_i.html", null ],
    [ "s", "globals_s.html", null ],
    [ "u", "globals_u.html", null ]
];