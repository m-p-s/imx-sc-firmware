var modules =
[
    [ "IRQ: Interrupt Service", "group__IRQ__SVC.html", "group__IRQ__SVC" ],
    [ "MISC: Miscellaneous Service", "group__MISC__SVC.html", "group__MISC__SVC" ],
    [ "PAD: Pad Service", "group__PAD__SVC.html", "group__PAD__SVC" ],
    [ "PM: Power Management Service", "group__PM__SVC.html", "group__PM__SVC" ],
    [ "RM: Resource Management Service", "group__RM__SVC.html", "group__RM__SVC" ],
    [ "SECO: Security Service", "group__SECO__SVC.html", "group__SECO__SVC" ],
    [ "TIMER: Timer Service", "group__TIMER__SVC.html", "group__TIMER__SVC" ]
];