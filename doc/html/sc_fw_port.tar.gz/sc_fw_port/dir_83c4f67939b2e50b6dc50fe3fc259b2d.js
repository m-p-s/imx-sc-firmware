var dir_83c4f67939b2e50b6dc50fe3fc259b2d =
[
    [ "drc", "dir_787d645037301ae40f7d8181ac75a0ba.html", "dir_787d645037301ae40f7d8181ac75a0ba" ],
    [ "igpio", "dir_695421cc36b9b5355445d751498b0174.html", "dir_695421cc36b9b5355445d751498b0174" ],
    [ "lpi2c", "dir_9986937d5c2d55a7e5d1d4820166229f.html", "dir_9986937d5c2d55a7e5d1d4820166229f" ],
    [ "lpuart", "dir_b1c4d21f93a7826ef4aed70b30552b97.html", "dir_b1c4d21f93a7826ef4aed70b30552b97" ],
    [ "pmic", "dir_c3bcce33382019f75311cf08b00f60e6.html", "dir_c3bcce33382019f75311cf08b00f60e6" ],
    [ "rgpio", "dir_c2413eacf765d2d058d00260a2581a98.html", "dir_c2413eacf765d2d058d00260a2581a98" ],
    [ "seco", "dir_0132e34d48c9ac6980becc9aa4ef056f.html", "dir_0132e34d48c9ac6980becc9aa4ef056f" ],
    [ "snvs", "dir_7563197b02cd5f6f007403130700e876.html", "dir_7563197b02cd5f6f007403130700e876" ],
    [ "wdog32", "dir_03539e9bf34fd65c5e6da2760226d874.html", "dir_03539e9bf34fd65c5e6da2760226d874" ]
];