var structsoc__cluster__state__t =
[
    [ "rm_idx", "structsoc__cluster__state__t.html#a3939b32f658cedc7900101d4ba9c72d7", null ],
    [ "num_cpu", "structsoc__cluster__state__t.html#a25980155eca568aaed946a2e8e00e4af", null ],
    [ "cpu_state", "structsoc__cluster__state__t.html#a2378bad0acd79a09df27aa81a87a23c0", null ],
    [ "req_mode", "structsoc__cluster__state__t.html#af4c1bd6bad7982bbaf2dd3e2930e10dd", null ]
];