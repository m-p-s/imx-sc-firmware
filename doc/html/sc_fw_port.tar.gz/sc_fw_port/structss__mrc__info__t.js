var structss__mrc__info__t =
[
    [ "start", "structss__mrc__info__t.html#ada9ab032419b43e381355c80b386aeaf", null ],
    [ "end", "structss__mrc__info__t.html#af695190545c83b4551b40903d18bb7b1", null ],
    [ "adjust", "structss__mrc__info__t.html#a038b560b7465fa140c0e58596143f8e8", null ],
    [ "cache", "structss__mrc__info__t.html#a30887da59ed015b8aa867ecd9d4e601b", null ],
    [ "mrc", "structss__mrc__info__t.html#ab52bdff60e37e11132861c959edf6fad", null ],
    [ "idx", "structss__mrc__info__t.html#a5344bf10f0f9636f5e5015ed218fa036", null ],
    [ "num_slots", "structss__mrc__info__t.html#a94d6ff32ea9dbf1ec6fe0e9f9b4e84a7", null ],
    [ "pd", "structss__mrc__info__t.html#aea25ed5c784877196c18a0be3064a15b", null ],
    [ "sub", "structss__mrc__info__t.html#a8b0dd1af75337ec56d2c5d6d85e9585f", null ],
    [ "present", "structss__mrc__info__t.html#acd4d9510156fbad7f47a820cbeebab4c", null ]
];