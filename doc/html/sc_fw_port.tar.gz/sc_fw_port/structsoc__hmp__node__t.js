var structsoc__hmp__node__t =
[
    [ "rm_idx", "structsoc__hmp__node__t.html#afcd1453b3ad11e03017bdcfbccd01a0a", null ],
    [ "sys_if_req", "structsoc__hmp__node__t.html#a41a2805ff8f170fe004f6e478c3387e0", null ]
];