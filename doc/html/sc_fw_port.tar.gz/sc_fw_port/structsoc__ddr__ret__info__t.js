var structsoc__ddr__ret__info__t =
[
    [ "num_drc", "structsoc__ddr__ret__info__t.html#a1a17a5e3e1010c50254192cf7059ae75", null ],
    [ "drc_inst", "structsoc__ddr__ret__info__t.html#a6605a3742b67f85e9afb2a167ba06492", null ],
    [ "drc_phy_inst", "structsoc__ddr__ret__info__t.html#a2e2326a3d1e198ab907586c684985ff4", null ],
    [ "num_region", "structsoc__ddr__ret__info__t.html#a99ad80a34419be78986bc52de54f4891", null ],
    [ "region", "structsoc__ddr__ret__info__t.html#a146d34a7ff5d5cd39750289ff730a8c3", null ],
    [ "drc0_clk_rate", "structsoc__ddr__ret__info__t.html#a5f84b0fd5050cbbd6fa3ae2fc723bf1b", null ]
];