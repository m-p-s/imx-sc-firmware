var structsoc__hmp__t =
[
    [ "num_hmp", "structsoc__hmp__t.html#aa3fa54e1ddc8744d2b489c25d2b3b871", null ],
    [ "hmp_node", "structsoc__hmp__t.html#a461baa4dd18e19f0c1d69d0a62406633", null ],
    [ "num_sys_if", "structsoc__hmp__t.html#af958691d89cc0d15ccd41085c3e1a274", null ],
    [ "sys_if_node", "structsoc__hmp__t.html#a3a3a5d3bb904dba2b7b86c100a7ccd2c", null ],
    [ "sys_if_mgmt", "structsoc__hmp__t.html#a21a1b552459eb6f69aa89ec943f4ede2", null ],
    [ "ap_gic_rm_idx", "structsoc__hmp__t.html#a2ef650f286198c617e85a9170a738a02", null ],
    [ "ap_irqstr_rm_idx", "structsoc__hmp__t.html#a40b88ffdf02e5bd572850775ff992846", null ],
    [ "ap_resume_cluster_idx", "structsoc__hmp__t.html#a38d372186e05ea8f50e2e7b47453da55", null ],
    [ "ap_resume_cpu_idx", "structsoc__hmp__t.html#a3fbc183ef2504767bcbe9eea9fdff1b2", null ],
    [ "ocmem_mode", "structsoc__hmp__t.html#a53ad61176e214a2dd796a8bd51412c1c", null ],
    [ "fspi_ret_info", "structsoc__hmp__t.html#ac9202ff60487ebe2c88da035babd9584", null ],
    [ "ddr_mode", "structsoc__hmp__t.html#a0288722051cd10ff70765a0bc24c2096", null ],
    [ "ddr_active", "structsoc__hmp__t.html#ad8251f127c209471293b48183c523683", null ],
    [ "lpm_active", "structsoc__hmp__t.html#ac0067aa38e1d09166a5849f1b74f3505", null ]
];