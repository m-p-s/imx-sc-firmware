var structsoc__patch__area__list__t =
[
    [ "offset", "structsoc__patch__area__list__t.html#ad19491a790bdf320059fbcfa9ae6477c", null ],
    [ "len", "structsoc__patch__area__list__t.html#acaaf499013d7fbbfe159b6efa755a545", null ]
];