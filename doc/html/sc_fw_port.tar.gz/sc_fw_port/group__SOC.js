var group__SOC =
[
    [ "soc_patch_area_list_t", "structsoc__patch__area__list__t.html", [
      [ "offset", "structsoc__patch__area__list__t.html#ad19491a790bdf320059fbcfa9ae6477c", null ],
      [ "len", "structsoc__patch__area__list__t.html#acaaf499013d7fbbfe159b6efa755a545", null ]
    ] ],
    [ "soc_freq_volt_tbl_t", "structsoc__freq__volt__tbl__t.html", [
      [ "freq", "structsoc__freq__volt__tbl__t.html#ae8ba00f65a94d6b09f76e851ac9678e1", null ],
      [ "volt", "structsoc__freq__volt__tbl__t.html#a885bd1e78982612e20f028166b6c283d", null ],
      [ "bias", "structsoc__freq__volt__tbl__t.html#a49dd4900b15be8e2742a5ccfdc41dff1", null ]
    ] ],
    [ "soc_gpu_clks_opp_t", "structsoc__gpu__clks__opp__t.html", [
      [ "shader_clk", "structsoc__gpu__clks__opp__t.html#a8afb46ec4b2b5727b2b355cd40eb1201", null ],
      [ "core_clk", "structsoc__gpu__clks__opp__t.html#a067b3f72565e4148cd07649597125993", null ],
      [ "ahb_clk", "structsoc__gpu__clks__opp__t.html#a1adf4e9a3a2e05e4d9c047a13990155c", null ],
      [ "axi_ssi_clk", "structsoc__gpu__clks__opp__t.html#aa3792afee0743e592d2bcc2a8c05d6f8", null ]
    ] ],
    [ "soc_cpu_state_t", "structsoc__cpu__state__t.html", [
      [ "rm_idx", "structsoc__cpu__state__t.html#a9e7a2ca25d955a971a106333a49bdcb6", null ],
      [ "req_mode", "structsoc__cpu__state__t.html#aaafc4c090e129483d7ab04531487b00d", null ],
      [ "lpm_active", "structsoc__cpu__state__t.html#a267c5339bc84cd369007c40a5e3ce7a4", null ],
      [ "rst_req", "structsoc__cpu__state__t.html#a78edc942856341f9680a12eec468f18b", null ],
      [ "early_wake", "structsoc__cpu__state__t.html#a0117c8bf810513b99ca15fd264fcba95", null ],
      [ "wake_idx", "structsoc__cpu__state__t.html#a40a8de2572be7fb88459d53cd64e0933", null ],
      [ "wake_src", "structsoc__cpu__state__t.html#a83ada33a4d22cb585959fcb254f45fab", null ],
      [ "resume_addr", "structsoc__cpu__state__t.html#ab878d20368516acb6f45698840b8da5f", null ]
    ] ],
    [ "soc_cluster_state_t", "structsoc__cluster__state__t.html", [
      [ "rm_idx", "structsoc__cluster__state__t.html#a3939b32f658cedc7900101d4ba9c72d7", null ],
      [ "num_cpu", "structsoc__cluster__state__t.html#a25980155eca568aaed946a2e8e00e4af", null ],
      [ "cpu_state", "structsoc__cluster__state__t.html#a2378bad0acd79a09df27aa81a87a23c0", null ],
      [ "req_mode", "structsoc__cluster__state__t.html#af4c1bd6bad7982bbaf2dd3e2930e10dd", null ]
    ] ],
    [ "soc_multicluster_state_t", "structsoc__multicluster__state__t.html", [
      [ "rm_idx", "structsoc__multicluster__state__t.html#a47e9b945a637cf4ed1aa8551efb826c6", null ],
      [ "cluster_state", "structsoc__multicluster__state__t.html#a7df93122ab7524e6da81a943e93a4eb6", null ],
      [ "req_mode", "structsoc__multicluster__state__t.html#ad090766478c242da13a7d3c7f08803e0", null ]
    ] ],
    [ "soc_m4_state_t", "structsoc__m4__state__t.html", [
      [ "wic_rm_idx", "structsoc__m4__state__t.html#a2b34cbcf974b7adc782bd6015b0e715f", null ],
      [ "sc_mu_rm_idx", "structsoc__m4__state__t.html#af5db0a8145f50e7a7fa38f2fd7753055", null ],
      [ "dsm_req", "structsoc__m4__state__t.html#a447ff188f21263134e1cf03e65daddac", null ],
      [ "dsm_active", "structsoc__m4__state__t.html#a1b308f243680684a4812aaf2a9b48347", null ],
      [ "rst_req", "structsoc__m4__state__t.html#a016c86a49a6ef13de1e156dfec22719c", null ],
      [ "stopm", "structsoc__m4__state__t.html#a5ed13601af888bdfc9aa8d83a431d1b3", null ],
      [ "pstopo", "structsoc__m4__state__t.html#a83980bf48f7f79f534379f78c58073f9", null ],
      [ "resume_addr", "structsoc__m4__state__t.html#a191f0d1874e1c0de8f0a18e4e0bcc521", null ]
    ] ],
    [ "soc_sys_if_node_t", "structsoc__sys__if__node__t.html", [
      [ "num_rm_idx", "structsoc__sys__if__node__t.html#a72ee6009d3eb0dcc6b110e4a7d255bd8", null ],
      [ "rsrc", "structsoc__sys__if__node__t.html#a94c26a9d98def3c0c88e83a75af0d164", null ],
      [ "rm_idx", "structsoc__sys__if__node__t.html#a56a4c54ec182ae381da2780a31429052", null ],
      [ "saved_pm", "structsoc__sys__if__node__t.html#a3d22405ab0908579e33e7b9013452827", null ]
    ] ],
    [ "soc_sys_if_req_t", "structsoc__sys__if__req__t.html", [
      [ "hpm", "structsoc__sys__if__req__t.html#ad62f7e2cf0bca642659615f6675b5a41", null ],
      [ "lpm", "structsoc__sys__if__req__t.html#a418a6274930d2753352e7319d8d5242d", null ]
    ] ],
    [ "soc_hmp_node_t", "structsoc__hmp__node__t.html", [
      [ "rm_idx", "structsoc__hmp__node__t.html#afcd1453b3ad11e03017bdcfbccd01a0a", null ],
      [ "sys_if_req", "structsoc__hmp__node__t.html#a41a2805ff8f170fe004f6e478c3387e0", null ]
    ] ],
    [ "soc_fspi_ret_info_t", "structsoc__fspi__ret__info__t.html", [
      [ "pm", "structsoc__fspi__ret__info__t.html#aa796e286a4388b0b16f509583e4612b1", null ],
      [ "clk_rate", "structsoc__fspi__ret__info__t.html#a5d557582e30dd88372e3f34d2e3da2e9", null ]
    ] ],
    [ "soc_hmp_t", "structsoc__hmp__t.html", [
      [ "num_hmp", "structsoc__hmp__t.html#aa3fa54e1ddc8744d2b489c25d2b3b871", null ],
      [ "hmp_node", "structsoc__hmp__t.html#a461baa4dd18e19f0c1d69d0a62406633", null ],
      [ "num_sys_if", "structsoc__hmp__t.html#af958691d89cc0d15ccd41085c3e1a274", null ],
      [ "sys_if_node", "structsoc__hmp__t.html#a3a3a5d3bb904dba2b7b86c100a7ccd2c", null ],
      [ "sys_if_mgmt", "structsoc__hmp__t.html#a21a1b552459eb6f69aa89ec943f4ede2", null ],
      [ "ap_gic_rm_idx", "structsoc__hmp__t.html#a2ef650f286198c617e85a9170a738a02", null ],
      [ "ap_irqstr_rm_idx", "structsoc__hmp__t.html#a40b88ffdf02e5bd572850775ff992846", null ],
      [ "ap_resume_cluster_idx", "structsoc__hmp__t.html#a38d372186e05ea8f50e2e7b47453da55", null ],
      [ "ap_resume_cpu_idx", "structsoc__hmp__t.html#a3fbc183ef2504767bcbe9eea9fdff1b2", null ],
      [ "ocmem_mode", "structsoc__hmp__t.html#a53ad61176e214a2dd796a8bd51412c1c", null ],
      [ "fspi_ret_info", "structsoc__hmp__t.html#ac9202ff60487ebe2c88da035babd9584", null ],
      [ "ddr_mode", "structsoc__hmp__t.html#a0288722051cd10ff70765a0bc24c2096", null ],
      [ "ddr_active", "structsoc__hmp__t.html#ad8251f127c209471293b48183c523683", null ],
      [ "lpm_active", "structsoc__hmp__t.html#ac0067aa38e1d09166a5849f1b74f3505", null ]
    ] ],
    [ "soc_ddr_ret_region_t", "structsoc__ddr__ret__region__t.html", [
      [ "addr", "structsoc__ddr__ret__region__t.html#aec14eb634005f0222510a18eb0f6101d", null ],
      [ "size", "structsoc__ddr__ret__region__t.html#a5f9c10d9d38193392b6125ec8899419f", null ],
      [ "buf", "structsoc__ddr__ret__region__t.html#ab59c11d094a4f335b23e580066305654", null ]
    ] ],
    [ "soc_ddr_ret_info_t", "structsoc__ddr__ret__info__t.html", [
      [ "num_drc", "structsoc__ddr__ret__info__t.html#a1a17a5e3e1010c50254192cf7059ae75", null ],
      [ "drc_inst", "structsoc__ddr__ret__info__t.html#a6605a3742b67f85e9afb2a167ba06492", null ],
      [ "drc_phy_inst", "structsoc__ddr__ret__info__t.html#a2e2326a3d1e198ab907586c684985ff4", null ],
      [ "num_region", "structsoc__ddr__ret__info__t.html#a99ad80a34419be78986bc52de54f4891", null ],
      [ "region", "structsoc__ddr__ret__info__t.html#a146d34a7ff5d5cd39750289ff730a8c3", null ],
      [ "drc0_clk_rate", "structsoc__ddr__ret__info__t.html#a5f84b0fd5050cbbd6fa3ae2fc723bf1b", null ]
    ] ],
    [ "soc_dqs2dq_sync_info_t", "structsoc__dqs2dq__sync__info__t.html", [
      [ "isi_rsrc", "structsoc__dqs2dq__sync__info__t.html#a72899eed0249f8a2a8227fab14e10c27", null ],
      [ "isi_regs", "structsoc__dqs2dq__sync__info__t.html#a05527e1ead950fac2f77671e62785c38", null ],
      [ "timeout_usec", "structsoc__dqs2dq__sync__info__t.html#ab4a5bb322f960f9a9dec57f0b2440d4c", null ]
    ] ],
    [ "soc_msi_ring_usecount_t", "structsoc__msi__ring__usecount__t.html", [
      [ "rsrc", "structsoc__msi__ring__usecount__t.html#a054ed0a9e219c63ef253c55300a57536", null ],
      [ "count", "structsoc__msi__ring__usecount__t.html#ad01f8b5e4ec3b40ed714e8d08de9a45b", null ],
      [ "ss_count", "structsoc__msi__ring__usecount__t.html#a7796a5f74f249b7604e0ad8e123eee73", null ]
    ] ],
    [ "STC_RCAT_SETCAT", "group__SOC.html#ga9ddd9065ed985565af2899bb22d23ec6", null ],
    [ "STC_RCAT_SETSTARTSTOPTDM", "group__SOC.html#ga8dd317b3c8a1c1b9ffb83fadd67bc704", null ],
    [ "STC_RCAT_GETHPR", "group__SOC.html#gac636cda24b97eee5cfaed40d2fae6d65", null ],
    [ "STC_RCAT_SETHPR", "group__SOC.html#ga02e437d46e3fb47f27cd6119e218331b", null ],
    [ "STC_QOS_PANIC", "group__SOC.html#gab2ec7957e58b395bd4ac4be59f1d0f07", null ],
    [ "STC_UD_THRESHOLD1", "group__SOC.html#ga6a37c31b994b85c1865fd773205253ac", null ],
    [ "STC_UD_THRESHOLD2", "group__SOC.html#ga95575ef7bd982271abc6996e446ff905", null ],
    [ "STC_UD_DIS", "group__SOC.html#ga47fa441f6ce2d17b0a48582f93c595bf", null ],
    [ "SOC_RR", "group__SOC.html#gaa77299ecf43345e0cef9368ac4703bfb", null ],
    [ "SOC_RR_CHECK", "group__SOC.html#gab411c19afd9605120f955cee9b0ee800", null ],
    [ "SOC_RR_INFO", "group__SOC.html#gad7b53ed650608a4b3519768b8b2f3858", null ],
    [ "SOC_RR_REASON", "group__SOC.html#gade7cf7a0fc132437bc05b0be7ecbb8ce", null ],
    [ "SOC_RR_PT", "group__SOC.html#ga8027814f4f96016bdfe340f55c2cfaea", null ],
    [ "soc_init_common", "group__SOC.html#ga18319091ded5a9dd4bb3e7379edd2398", null ],
    [ "soc_init", "group__SOC.html#ga618dec158647e9866923d6aa0e88dfae", null ],
    [ "soc_config_sc", "group__SOC.html#ga34f1cf5b123a549a3479a87035452ef5", null ],
    [ "soc_config_seco", "group__SOC.html#gae63c83672341772bc7877c227b31d2a7", null ],
    [ "soc_db_stc_config", "group__SOC.html#ga9f94c9cff17ec32850fee1eb11cfcede", null ],
    [ "soc_init_fused_rsrc", "group__SOC.html#gab31d13fcb656b53caa3fa0f1f6937703", null ],
    [ "soc_ss_notavail", "group__SOC.html#ga25fe80aeea5ad85ab1d199865eaca767", null ],
    [ "soc_init_refgen", "group__SOC.html#ga57e59c063833804a81cca6dc6dc66426", null ],
    [ "soc_analog_fuse_init", "group__SOC.html#ga072550f5cb4b6142b5b36096e95a7c4f", null ],
    [ "soc_set_reset_info", "group__SOC.html#gab42e6283c6ffc54719ce7564f9cb9c1d", null ],
    [ "soc_reset_reason", "group__SOC.html#gaa5d5703b48185990e3292f11241c6e4f", null ],
    [ "soc_reset_part", "group__SOC.html#gacbdde513ba8168abd6a744c8803ecd1a", null ],
    [ "soc_rsrc_avail", "group__SOC.html#ga92caab2808650e2983de1278093e42ca", null ],
    [ "soc_get_temp_trim", "group__SOC.html#gafca12a4d094249f67c2827edd6647542", null ],
    [ "soc_get_temp_ofs", "group__SOC.html#gae83973ad664cf0e0ec47f2dbfc077147", null ],
    [ "soc_get_max_freq", "group__SOC.html#ga67c34577c755493e84e8f8615d74b451", null ],
    [ "soc_enet_get_freq_limit", "group__SOC.html#ga0e1d1d6f5bb3217090bf74d949255c21", null ],
    [ "soc_get_max_freq_fuse", "group__SOC.html#ga790d8979622d24485dd2c1d46d0db33b", null ],
    [ "soc_pd_switchable", "group__SOC.html#gaeb7ebcd576d211c260d5af8e30942d84", null ],
    [ "soc_pd_retention", "group__SOC.html#ga46b365841f0c9e84a8567741596f6110", null ],
    [ "soc_ss_has_bias", "group__SOC.html#gad6d6bed5c2497cfb64ff181645671dc7", null ],
    [ "soc_ss_ai_type", "group__SOC.html#ga8b7532e22341c4dc6b7ceb1df679e1a6", null ],
    [ "soc_mem_type", "group__SOC.html#ga6d60b242d7a37449047cd4408cca77a7", null ],
    [ "soc_mem_pwr_plane", "group__SOC.html#ga6898d7ea1a6bd26ac087f4a4808cf85d", null ],
    [ "soc_dsc_clock_info", "group__SOC.html#ga2c6a67d0cec398bf7423d2e316831f6c", null ],
    [ "soc_get_clock_div", "group__SOC.html#ga9dc0dceb0d920275d385775e2bdf4197", null ],
    [ "soc_slice_is_dsc", "group__SOC.html#ga8b90295d2d1ea6df3b077ca4dbff9ab3", null ],
    [ "soc_get_avpll_ssc_n", "group__SOC.html#ga33a219de8261bb0fc544f89cad2b439d", null ],
    [ "soc_gpu_freq_hw_limited", "group__SOC.html#ga614a83b91e2f32f58e09aaea1b8c72b4", null ],
    [ "soc_rompatch_checksum", "group__SOC.html#gadc0abd54332e527917262f1b6c83cbc7", null ],
    [ "soc_setup_anamix", "group__SOC.html#ga0d5ea124963d49b75c193dfa77a43737", null ],
    [ "soc_dsc_powerup_anamix", "group__SOC.html#gae11a15683b7970c547ee57a7afd67e97", null ],
    [ "soc_dsc_powerup_phymix", "group__SOC.html#ga38ae99b832d7ee7856357394ccb3fac5", null ],
    [ "soc_dsc_powerdown_anamix", "group__SOC.html#ga719c24835b10bc2f06f95ae0fb188644", null ],
    [ "soc_dsc_powerdown_phymix", "group__SOC.html#ga5eaaf6c38cc3b487ba1517d0372f47a3", null ],
    [ "soc_setup_hsio_repeater", "group__SOC.html#ga4f880cd171dc3f313fe232f19a7db99a", null ],
    [ "soc_set_bias", "group__SOC.html#ga467ed6ef27f2055dd8aab2bd57f51789", null ],
    [ "soc_dpll_dco_pc", "group__SOC.html#gaff1d15a9d5bdef8b9bb3d2f5b158d00b", null ],
    [ "soc_dpll_populate_tbl", "group__SOC.html#ga159cee6cc3ed05584e841a66ed526afb", null ],
    [ "soc_set_freq_voltage", "group__SOC.html#ga036da0c031d717bd248f691b2833f491", null ],
    [ "soc_trans_pd", "group__SOC.html#ga4485cce6c702affd4cde0eb8791e3c92", null ],
    [ "soc_bias_enabled", "group__SOC.html#gac23204485ebcb7e496bb274a53277f7d", null ],
    [ "soc_ss_has_vd_detect", "group__SOC.html#gaa82b0f8fb28761f3291b0340d6706248", null ],
    [ "soc_trans_bandgap", "group__SOC.html#ga283476363b07260d52effed87755ea34", null ],
    [ "soc_init_ddr", "group__SOC.html#ga414f99ae2d2bbaa96e8315a4744a0981", null ],
    [ "soc_self_refresh_power_down_clk_disable_entry", "group__SOC.html#gaf4402154977330b487a01c557af18931", null ],
    [ "soc_refresh_power_down_clk_disable_exit", "group__SOC.html#ga6e024b5d85f2576d9ece02fc0ac90a62", null ],
    [ "soc_ddr_config_retention", "group__SOC.html#ga3ade1e9fcaa89d7309561ead5aa2086f", null ],
    [ "soc_ddr_enter_retention", "group__SOC.html#gad8dedee85749ef29fe7ab3fd11846d8b", null ],
    [ "soc_ddr_exit_retention", "group__SOC.html#ga66f9dbbfdc12db8e235ee2a9bea64f13", null ],
    [ "soc_ddr_dqs2dq_init", "group__SOC.html#ga5c77ab380aa01c7aaecf099a2a2d538d", null ],
    [ "soc_ddr_bit_deskew", "group__SOC.html#ga42b8310804ece9c4c40cd91aa4531d57", null ],
    [ "soc_ddr_dqs2dq_periodic", "group__SOC.html#ga7d275ea475a4c293474a18bdaf98f172", null ],
    [ "soc_ddr_dqs2dq_config", "group__SOC.html#ga89b55c182d58c31bb213d0fb9bbff5e6", null ],
    [ "soc_ddr_dqs2dq_sync", "group__SOC.html#gacc632ef4f52421906f8b6c63db45bdc1", null ],
    [ "soc_drc_lpcg_setup", "group__SOC.html#ga759e2cb6421c58e416008cd89c5611d8", null ],
    [ "soc_temp_sensor_tick", "group__SOC.html#ga19e7c2779d6e9fc664e317e73ab9c8c0", null ],
    [ "soc_dsc_ai_dumpmodule", "group__SOC.html#gaf68826b919caf2710768cf005e828818", null ],
    [ "soc_dsc_ai_dump", "group__SOC.html#ga2f208cb80f9959cbdc4860afd8c4e3e9", null ],
    [ "soc_anamix_test_out", "group__SOC.html#gabddbe2934d906197a1f0623f0ee5bb2f", null ],
    [ "soc_reset_pt", "group__SOC.html#ga70e7d3387df5179f5b91a9f91ba2f92c", null ],
    [ "soc_reset_rsn", "group__SOC.html#ga9ea53ee8b813de972ca7b0550aa8c010", null ],
    [ "soc_clk_off_trans", "group__SOC.html#ga038991c9658954083bc481d6c04a6773", null ],
    [ "soc_hmp", "group__SOC.html#ga869e67df10859187b7b22b36d508f497", null ]
];