var structss__pd__info__t =
[
    [ "reset_mask", "structss__pd__info__t.html#af44e5af8b02f70fd9bb9b65f95356d5c", null ]
];