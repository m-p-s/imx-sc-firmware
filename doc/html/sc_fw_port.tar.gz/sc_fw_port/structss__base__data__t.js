var structss__base__data__t =
[
    [ "clk_data", "structss__base__data__t.html#af0caedeb57e857dffdc83abff4754498", null ],
    [ "num_pll", "structss__base__data__t.html#ab86c8709d088443e9c7af6a317bae378", null ],
    [ "usecount", "structss__base__data__t.html#a77c851c0f4b1eeb3311205c1878055ce", null ],
    [ "power_mode", "structss__base__data__t.html#adce3106faa67a558c56e4d76dae98588", null ],
    [ "master_did", "structss__base__data__t.html#ab75e3db869c2ddd450e122290707a8e1", null ]
];