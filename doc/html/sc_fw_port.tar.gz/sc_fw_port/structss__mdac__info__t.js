var structss__mdac__info__t =
[
    [ "num_slots", "structss__mdac__info__t.html#add2ff3577ec4c1bb3dd2358274501715", null ],
    [ "pd", "structss__mdac__info__t.html#a4242ef2764d9fe357024d427566f164e", null ],
    [ "cid", "structss__mdac__info__t.html#ae84317d486d74447ede8754a1899f202", null ],
    [ "present", "structss__mdac__info__t.html#aba2f3026452d33d362a755c691c8133b", null ],
    [ "cache", "structss__mdac__info__t.html#a113212efde12e500f987bb2302730832", null ]
];