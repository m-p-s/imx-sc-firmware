var globals_defs =
[
    [ "a", "globals_defs.html", null ],
    [ "b", "globals_defs_b.html", null ],
    [ "c", "globals_defs_c.html", null ],
    [ "f", "globals_defs_f.html", null ],
    [ "i", "globals_defs_i.html", null ],
    [ "m", "globals_defs_m.html", null ],
    [ "n", "globals_defs_n.html", null ],
    [ "p", "globals_defs_p.html", null ],
    [ "r", "globals_defs_r.html", null ],
    [ "s", "globals_defs_s.html", null ],
    [ "t", "globals_defs_t.html", null ],
    [ "u", "globals_defs_u.html", null ],
    [ "v", "globals_defs_v.html", null ],
    [ "w", "globals_defs_w.html", null ],
    [ "x", "globals_defs_x.html", null ]
];