var structsoc__freq__volt__tbl__t =
[
    [ "freq", "structsoc__freq__volt__tbl__t.html#ae8ba00f65a94d6b09f76e851ac9678e1", null ],
    [ "volt", "structsoc__freq__volt__tbl__t.html#a885bd1e78982612e20f028166b6c283d", null ],
    [ "bias", "structsoc__freq__volt__tbl__t.html#a49dd4900b15be8e2742a5ccfdc41dff1", null ]
];