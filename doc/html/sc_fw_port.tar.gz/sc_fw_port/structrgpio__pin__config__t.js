var structrgpio__pin__config__t =
[
    [ "pinDirection", "structrgpio__pin__config__t.html#a03ca848432e3f249e535756bfe0908b4", null ],
    [ "outputLogic", "structrgpio__pin__config__t.html#a0ce24e404fd7f867304a7deb933b0f53", null ]
];