var dir_36f0f90a961e87fe059bc30dfab96761 =
[
    [ "drivers", "dir_0862497c2188ccb611c33e282c10a500.html", "dir_0862497c2188ccb611c33e282c10a500" ],
    [ "board_common.h", "board__common_8h.html", "board__common_8h" ],
    [ "pmic.h", "pmic_8h.html", "pmic_8h" ]
];