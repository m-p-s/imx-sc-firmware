var structss__rsrc__info__t =
[
    [ "xrdc_master_idx", "structss__rsrc__info__t.html#a8cef1c3b5c676b04ac0b8043811c8ad5", null ],
    [ "xrdc_peripheral_idx", "structss__rsrc__info__t.html#a4f10b590d03287bbe7f851b6e0f5e4b1", null ],
    [ "xrdc_mda_match", "structss__rsrc__info__t.html#aebaa73879cf3a0edbe048b4d3a6b958c", null ],
    [ "xrdc_mda_mask", "structss__rsrc__info__t.html#a6b5a82fb9a474a23895570d6b0c77dc3", null ],
    [ "xexp_idx", "structss__rsrc__info__t.html#a2fb19e251ad046980d99445183e4447b", null ],
    [ "clk", "structss__rsrc__info__t.html#af4b5484fc269f7d2f288d1f161110cff", null ],
    [ "pd", "structss__rsrc__info__t.html#ae791e2438feaf5f329f5efbb02edd5a3", null ],
    [ "master", "structss__rsrc__info__t.html#a0212387519c58513b47a569b6f682544", null ],
    [ "peripheral", "structss__rsrc__info__t.html#a4e04ea3ddc6e598d05324906276f6239", null ]
];