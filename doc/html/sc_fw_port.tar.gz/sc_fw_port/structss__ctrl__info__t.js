var structss__ctrl__info__t =
[
    [ "bit", "structss__ctrl__info__t.html#aefc01f1086837d95a0f6938e68cb58ac", null ],
    [ "ss_idx", "structss__ctrl__info__t.html#abcfa1f4bda24f4e6cb9136bd8567ef20", null ],
    [ "width", "structss__ctrl__info__t.html#a6bd90b01573307d41ff2c49c60ecc29a", null ],
    [ "ctrl", "structss__ctrl__info__t.html#aebdfc5eeb40e9a73c4043caea49bb049", null ],
    [ "io", "structss__ctrl__info__t.html#a58771f9a409adbdf7420950eca43ecb6", null ]
];