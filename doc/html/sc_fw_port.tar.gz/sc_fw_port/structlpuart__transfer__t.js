var structlpuart__transfer__t =
[
    [ "data", "structlpuart__transfer__t.html#a7c49cf389dea8ad6f674bff6cedd8e37", null ],
    [ "dataSize", "structlpuart__transfer__t.html#ad269a833a8e8e4cdbc0d485d59e256d8", null ]
];