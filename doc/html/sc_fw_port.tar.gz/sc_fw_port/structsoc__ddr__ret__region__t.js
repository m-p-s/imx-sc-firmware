var structsoc__ddr__ret__region__t =
[
    [ "addr", "structsoc__ddr__ret__region__t.html#aec14eb634005f0222510a18eb0f6101d", null ],
    [ "size", "structsoc__ddr__ret__region__t.html#a5f9c10d9d38193392b6125ec8899419f", null ],
    [ "buf", "structsoc__ddr__ret__region__t.html#ab59c11d094a4f335b23e580066305654", null ]
];