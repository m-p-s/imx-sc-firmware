var struct__lpi2c__master__transfer =
[
    [ "flags", "struct__lpi2c__master__transfer.html#a1c11b4cb590384ca6a8f9b8b43d23558", null ],
    [ "slaveAddress", "struct__lpi2c__master__transfer.html#a7b9a1f78b5cf27502969224775e2134b", null ],
    [ "direction", "struct__lpi2c__master__transfer.html#af9c1114cb5c6834f07c2069e39faba17", null ],
    [ "subaddress", "struct__lpi2c__master__transfer.html#a377ed24db3b848a1253bc9a5344e732f", null ],
    [ "subaddressSize", "struct__lpi2c__master__transfer.html#abb7feabae4704bcf7b090d50b6d9c951", null ],
    [ "data", "struct__lpi2c__master__transfer.html#a6f242bd0a1ce4821c7d1d26074b29a9d", null ],
    [ "dataSize", "struct__lpi2c__master__transfer.html#a79682c750a97b52d05515165f3f530e1", null ]
];