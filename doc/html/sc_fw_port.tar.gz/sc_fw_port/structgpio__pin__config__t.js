var structgpio__pin__config__t =
[
    [ "direction", "structgpio__pin__config__t.html#a5eae83ead0519707b896cfa9082c4e82", null ],
    [ "outputLogic", "structgpio__pin__config__t.html#a9d37ffd9a2943f10a91095759bd52da5", null ],
    [ "interruptMode", "structgpio__pin__config__t.html#a2aaf4ec1e85d3fcea653b422c673441e", null ]
];