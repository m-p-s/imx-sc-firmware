var structsoc__fspi__ret__info__t =
[
    [ "pm", "structsoc__fspi__ret__info__t.html#aa796e286a4388b0b16f509583e4612b1", null ],
    [ "clk_rate", "structsoc__fspi__ret__info__t.html#a5d557582e30dd88372e3f34d2e3da2e9", null ]
];