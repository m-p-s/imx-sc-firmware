var structsoc__sys__if__req__t =
[
    [ "hpm", "structsoc__sys__if__req__t.html#ad62f7e2cf0bca642659615f6675b5a41", null ],
    [ "lpm", "structsoc__sys__if__req__t.html#a418a6274930d2753352e7319d8d5242d", null ]
];