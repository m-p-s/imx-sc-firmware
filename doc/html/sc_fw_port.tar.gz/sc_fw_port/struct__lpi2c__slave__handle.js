var struct__lpi2c__slave__handle =
[
    [ "transfer", "struct__lpi2c__slave__handle.html#aed2dec763e40c6caa129c082603852d5", null ],
    [ "isBusy", "struct__lpi2c__slave__handle.html#a8f0662c2c78df7b8e8b5ed4c1119823d", null ],
    [ "wasTransmit", "struct__lpi2c__slave__handle.html#af0a187d43f251bc67fb9c34dedbf9253", null ],
    [ "eventMask", "struct__lpi2c__slave__handle.html#a5bceee16dd6f07c8cb6918580e45e540", null ],
    [ "transferredCount", "struct__lpi2c__slave__handle.html#ac9f4d0665e8ec4c56eb89e816c4b5324", null ],
    [ "callback", "struct__lpi2c__slave__handle.html#a0e16ba71a57adfe84058af632a604e40", null ],
    [ "userData", "struct__lpi2c__slave__handle.html#aa394f46d8677c977aa39b64fb0c353ce", null ]
];