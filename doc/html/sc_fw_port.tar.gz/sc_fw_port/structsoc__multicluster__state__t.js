var structsoc__multicluster__state__t =
[
    [ "rm_idx", "structsoc__multicluster__state__t.html#a47e9b945a637cf4ed1aa8551efb826c6", null ],
    [ "cluster_state", "structsoc__multicluster__state__t.html#a7df93122ab7524e6da81a943e93a4eb6", null ],
    [ "req_mode", "structsoc__multicluster__state__t.html#ad090766478c242da13a7d3c7f08803e0", null ]
];