var board__common_8h =
[
    [ "test_drv", "group__BRD__SVC.html#gab72b42937c8b3f0918b25b4f8262d043", null ],
    [ "test_sc", "group__BRD__SVC.html#ga9b047b90abf5d21c97efa6b371495967", null ],
    [ "test_ap", "group__BRD__SVC.html#ga0d12fc87f77f32375903bc85a3303e54", null ],
    [ "board_monitor", "group__BRD__SVC.html#ga9372eb31647103e5a7394b7314578141", null ],
    [ "board_exit", "group__BRD__SVC.html#ga9b55472b7f9f36040cc840df7f3786e1", null ],
    [ "board_stdio", "group__BRD__SVC.html#ga12415c7e765457bea5c2a4a9a3e58250", null ],
    [ "board_printf", "group__BRD__SVC.html#gaf5652e48a9ff334d5009d8503aae3205", null ],
    [ "board_ddr_periodic_enable", "group__BRD__SVC.html#gabc5d5f7a3e48cd818b91389f5650d4ba", null ],
    [ "board_ddr_derate_periodic_enable", "group__BRD__SVC.html#gabff1c2a8451e901d974b896307bb540b", null ],
    [ "board_common_tick", "group__BRD__SVC.html#ga0c051d029f4e46bd7181af2a7fd9caf4", null ],
    [ "debug", "group__BRD__SVC.html#ga07428b6f747d1941a37a252f8aef4f15", null ],
    [ "has_test", "group__BRD__SVC.html#ga4080661413dcecdbca31d5051ef5ffa0", null ],
    [ "test_all", "group__BRD__SVC.html#ga074a6362e403bfc27b7d2fa498a0f942", null ],
    [ "has_monitor", "group__BRD__SVC.html#ga4ae22b31aec8193552f92eb21c315828", null ],
    [ "xrdc_nocheck", "group__BRD__SVC.html#ga6926ea4807dcb9014ba8a4875e351ea1", null ]
];