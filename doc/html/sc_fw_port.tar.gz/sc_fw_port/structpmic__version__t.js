var structpmic__version__t =
[
    [ "device_id", "structpmic__version__t.html#a0e79948977e8ba28b2dddd586c797280", null ],
    [ "si_rev", "structpmic__version__t.html#a94181a4131beda3f0396fff16fc23192", null ]
];