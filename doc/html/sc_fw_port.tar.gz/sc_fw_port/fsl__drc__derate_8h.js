var fsl__drc__derate_8h =
[
    [ "ddrc_lpddr4_derate_init", "group__drc__driver.html#ga1513eb2489e2136fb253a6c3231418ab", null ],
    [ "ddrc_lpddr4_derate_periodic", "group__drc__driver.html#gaf79ccd6f47c3f0b3559f635e66c85e97", null ]
];