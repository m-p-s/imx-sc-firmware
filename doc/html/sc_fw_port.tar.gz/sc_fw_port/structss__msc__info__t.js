var structss__msc__info__t =
[
    [ "pd", "structss__msc__info__t.html#ac9d142a4d101eb6ad3b620958a0b4381", null ],
    [ "present", "structss__msc__info__t.html#ad07c81dfddd36bb5f1fc237017868b6c", null ]
];