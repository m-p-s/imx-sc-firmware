var structwdog32__config__t =
[
    [ "enableWdog32", "structwdog32__config__t.html#ab80dd2f0e5475395f0e031e0811c127f", null ],
    [ "clockSource", "structwdog32__config__t.html#a55ee4dcaa7322068ae52fef6150f24a6", null ],
    [ "prescaler", "structwdog32__config__t.html#a7df5183ec267667a9e4c88e627da6cd8", null ],
    [ "workMode", "structwdog32__config__t.html#af0bac2121a846c18f1abd7180c0bef96", null ],
    [ "testMode", "structwdog32__config__t.html#a064f2be7cd3eb75072823c7fa55641fd", null ],
    [ "enableUpdate", "structwdog32__config__t.html#a40e63e94a31c56d510835d6071a1df85", null ],
    [ "enableInterrupt", "structwdog32__config__t.html#a17256555c7dc9048a7a1ab68c467ca63", null ],
    [ "enableWindowMode", "structwdog32__config__t.html#a3399d73ca4291a5883b578fccc95c091", null ],
    [ "windowValue", "structwdog32__config__t.html#aa60ca9f1ffe17c99d0178332497d2af5", null ],
    [ "timeoutValue", "structwdog32__config__t.html#a6ca6f4314b188418dcc82e9a8a6eb4c4", null ]
];