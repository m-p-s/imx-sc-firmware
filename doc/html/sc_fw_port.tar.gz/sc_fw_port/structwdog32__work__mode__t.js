var structwdog32__work__mode__t =
[
    [ "enableWait", "structwdog32__work__mode__t.html#a4eafd57a0902efab66232ab33de3c73d", null ],
    [ "enableStop", "structwdog32__work__mode__t.html#a89722846e36fbd9aaed4f45cf03fbe00", null ],
    [ "enableDebug", "structwdog32__work__mode__t.html#ae39601802486455524ca8f7f877ec0dc", null ]
];