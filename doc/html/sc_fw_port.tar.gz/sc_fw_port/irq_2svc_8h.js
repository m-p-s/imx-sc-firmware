var irq_2svc_8h =
[
    [ "irq_enable", "group__IRQ__SVC.html#ga0d64d5ad52f40f7a17477e8921653029", null ],
    [ "irq_status", "group__IRQ__SVC.html#ga0a5c4fa29c5db4d0aeb835b24b5d89b1", null ]
];