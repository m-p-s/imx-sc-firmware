var structsoc__gpu__clks__opp__t =
[
    [ "shader_clk", "structsoc__gpu__clks__opp__t.html#a8afb46ec4b2b5727b2b355cd40eb1201", null ],
    [ "core_clk", "structsoc__gpu__clks__opp__t.html#a067b3f72565e4148cd07649597125993", null ],
    [ "ahb_clk", "structsoc__gpu__clks__opp__t.html#a1adf4e9a3a2e05e4d9c047a13990155c", null ],
    [ "axi_ssi_clk", "structsoc__gpu__clks__opp__t.html#aa3792afee0743e592d2bcc2a8c05d6f8", null ]
];