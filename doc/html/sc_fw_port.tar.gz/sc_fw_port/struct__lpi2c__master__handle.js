var struct__lpi2c__master__handle =
[
    [ "state", "struct__lpi2c__master__handle.html#aa754ef003d1639ef78a69dbe450c9e72", null ],
    [ "remainingBytes", "struct__lpi2c__master__handle.html#a5a35aa5dfb9d0b99bf6b63d8ca2d0571", null ],
    [ "buf", "struct__lpi2c__master__handle.html#a54a8e0398a4a439336f677034a221e29", null ],
    [ "commandBuffer", "struct__lpi2c__master__handle.html#ad4580490ec11fe2ce2f12143a5ad55a0", null ],
    [ "transfer", "struct__lpi2c__master__handle.html#a9c451e008467a29718e70cbc3c978a0c", null ],
    [ "completionCallback", "struct__lpi2c__master__handle.html#a45504c346312e5b6d8f0ee3e2a9be3c6", null ],
    [ "userData", "struct__lpi2c__master__handle.html#a6891adb76d1887f61142ecc89815dcd4", null ]
];