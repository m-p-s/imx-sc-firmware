var group__drc__driver =
[
    [ "fsl_drc_cbt.h", "fsl__drc__cbt_8h.html", null ],
    [ "fsl_drc_derate.h", "fsl__drc__derate_8h.html", null ],
    [ "fsl_drc_rdbi_deskew.h", "fsl__drc__rdbi__deskew_8h.html", null ],
    [ "run_cbt", "group__drc__driver.html#ga0280cc9008149a077d6bef2a350b917e", null ],
    [ "ddrc_lpddr4_derate_init", "group__drc__driver.html#ga1513eb2489e2136fb253a6c3231418ab", null ],
    [ "ddrc_lpddr4_derate_periodic", "group__drc__driver.html#gaf79ccd6f47c3f0b3559f635e66c85e97", null ],
    [ "RDBI_bit_deskew", "group__drc__driver.html#ga954c1b140d23772903dc1c86c3289c60", null ]
];