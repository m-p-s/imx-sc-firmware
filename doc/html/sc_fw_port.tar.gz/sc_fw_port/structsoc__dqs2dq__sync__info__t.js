var structsoc__dqs2dq__sync__info__t =
[
    [ "isi_rsrc", "structsoc__dqs2dq__sync__info__t.html#a72899eed0249f8a2a8227fab14e10c27", null ],
    [ "isi_regs", "structsoc__dqs2dq__sync__info__t.html#a05527e1ead950fac2f77671e62785c38", null ],
    [ "timeout_usec", "structsoc__dqs2dq__sync__info__t.html#ab4a5bb322f960f9a9dec57f0b2440d4c", null ]
];