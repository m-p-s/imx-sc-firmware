var structsoc__m4__state__t =
[
    [ "wic_rm_idx", "structsoc__m4__state__t.html#a2b34cbcf974b7adc782bd6015b0e715f", null ],
    [ "sc_mu_rm_idx", "structsoc__m4__state__t.html#af5db0a8145f50e7a7fa38f2fd7753055", null ],
    [ "dsm_req", "structsoc__m4__state__t.html#a447ff188f21263134e1cf03e65daddac", null ],
    [ "dsm_active", "structsoc__m4__state__t.html#a1b308f243680684a4812aaf2a9b48347", null ],
    [ "rst_req", "structsoc__m4__state__t.html#a016c86a49a6ef13de1e156dfec22719c", null ],
    [ "stopm", "structsoc__m4__state__t.html#a5ed13601af888bdfc9aa8d83a431d1b3", null ],
    [ "pstopo", "structsoc__m4__state__t.html#a83980bf48f7f79f534379f78c58073f9", null ],
    [ "resume_addr", "structsoc__m4__state__t.html#a191f0d1874e1c0de8f0a18e4e0bcc521", null ]
];