var pad_2svc_8h =
[
    [ "pad_init", "group__PAD__SVC.html#ga233d7129ec5191e94ee4da5b2b41821a", null ],
    [ "pad_set", "group__PAD__SVC.html#ga9a026c1780c52716f20b2f0f96cee7a9", null ],
    [ "pad_set_mux", "group__PAD__SVC.html#ga4027dd32148bf28e320dbc77065b7a37", null ],
    [ "pad_force_mux", "group__PAD__SVC.html#gaad0d027e1191c44c08cf4a86a367f73d", null ],
    [ "pad_set_gp", "group__PAD__SVC.html#gad4aa1997b873fdf3f962e47b9c2272c7", null ],
    [ "pad_set_wakeup", "group__PAD__SVC.html#gac214506e1194191738d08bc3749003ac", null ],
    [ "pad_set_all", "group__PAD__SVC.html#gaa936946432e76d1858ce76be92ba51c9", null ],
    [ "pad_get", "group__PAD__SVC.html#gae4cabdb7e8709514ec5417aab7e393a2", null ],
    [ "pad_get_mux", "group__PAD__SVC.html#gaa12b791a0db36d0931ab9ebf57658052", null ],
    [ "pad_get_gp", "group__PAD__SVC.html#gaf39e374424151e6f744a4be0bfb7ed59", null ],
    [ "pad_get_wakeup", "group__PAD__SVC.html#gaab3ba54edab4eedb4107cad6669b5541", null ],
    [ "pad_get_all", "group__PAD__SVC.html#gaef792b7266ff49ee1d825128d5d61bd3", null ],
    [ "pad_set_gp_28fdsoi", "group__PAD__SVC.html#ga6833caea349573c72fde6a0d3720ac5e", null ],
    [ "pad_get_gp_28fdsoi", "group__PAD__SVC.html#gaf43e567cef2aa723660fea886a007e16", null ],
    [ "pad_set_gp_28fdsoi_hsic", "group__PAD__SVC.html#ga6af97996429a63925ea5b60c7883e52b", null ],
    [ "pad_get_gp_28fdsoi_hsic", "group__PAD__SVC.html#ga390f0d689b26f4fb0832f54c1834a3a5", null ],
    [ "pad_set_gp_28fdsoi_comp", "group__PAD__SVC.html#ga510f5e5a8ddeeb78078f3e3f7b0f8286", null ],
    [ "pad_get_gp_28fdsoi_comp", "group__PAD__SVC.html#gaeb87922c9421f5ad061430e62b9bc02b", null ],
    [ "pad_config", "group__PAD__SVC.html#gaddb9a7484e3d423a384bbeaa53c060d2", null ],
    [ "pad_map_irq", "group__PAD__SVC.html#ga360eb183b60567c5109af9628bec0070", null ]
];