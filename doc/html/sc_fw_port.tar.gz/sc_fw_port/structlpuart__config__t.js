var structlpuart__config__t =
[
    [ "baudRate_Bps", "structlpuart__config__t.html#a09d359de28dc114424b2d702df014d1c", null ],
    [ "parityMode", "structlpuart__config__t.html#ae7ce86796f025a059c973c540d5a94ad", null ],
    [ "dataBitsCount", "structlpuart__config__t.html#a58ce25b71bde98b9c09875481637d120", null ],
    [ "isMsb", "structlpuart__config__t.html#aae9f69c98294d67da66edbce283f029b", null ],
    [ "rxIdleType", "structlpuart__config__t.html#accbd00b653a769831310e62f8a9045eb", null ],
    [ "rxIdleConfig", "structlpuart__config__t.html#a00e18786e55ac3057c2bc32b8bc0e361", null ],
    [ "enableTx", "structlpuart__config__t.html#a0d677467cd14ee90f544d688f3dc9b9a", null ],
    [ "enableRx", "structlpuart__config__t.html#a48d3f37a9364c0093083ef843d5d062e", null ]
];