/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2019 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as published by
the Free Software Foundation

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "System Controller Firmware Porting Guide", "index.html", [
    [ "Overview", "index.html", [
      [ "System Initialization and Boot", "index.html#INIT_SEC", null ],
      [ "System Controller Communication", "index.html#SCC_SEC", null ],
      [ "System Controller Services", "index.html#SCFS_SEC", [
        [ "Power Management Service", "index.html#PM_SEC", null ],
        [ "Resource Management Service", "index.html#RM_SEC", null ],
        [ "Pad Configuration Service", "index.html#PAD_SEC", null ],
        [ "Timer Service", "index.html#TIMER_SEC", null ],
        [ "Interrupt Service", "index.html#IRQ_SEC", null ],
        [ "Security Service", "index.html#SECO_SEC", null ],
        [ "Miscellaneous Service", "index.html#MISC_SEC", null ]
      ] ]
    ] ],
    [ "Disclaimer", "DISCLAIMER.html", null ],
    [ "Porting Guide", "PORT.html", [
      [ "Release", "PORT.html#PORT_RELEASE", null ],
      [ "Build Environment", "PORT.html#PORT_BUILD", null ],
      [ "Tool Chain", "PORT.html#PORT_TOOLCHAIN", null ],
      [ "Compiling the Code", "PORT.html#PORT_COMPILE", [
        [ "i.MX8QM (QP, some DM) Die Build", "PORT.html#autotoc_md0", null ],
        [ "i.MX8QX (QXP, DX, DXP) Die Build", "PORT.html#autotoc_md1", null ],
        [ "i.MX8DXL Die Build", "PORT.html#autotoc_md2", null ],
        [ "Generic Targets", "PORT.html#autotoc_md3", null ]
      ] ],
      [ "Production", "PORT.html#PORT_PROD", null ],
      [ "Porting", "PORT.html#PORT_PORTING", null ],
      [ "Porting Notes", "PORT.html#PORT_NOTES", null ],
      [ "Boot Flow", "PORT.html#PORT_BOOT", [
        [ "Standard Boot", "PORT.html#autotoc_md4", null ],
        [ "Early Boot", "PORT.html#autotoc_md5", null ]
      ] ],
      [ "SNVS and SECO", "PORT.html#PORT_SNVS", null ],
      [ "Power Management IC", "PORT.html#PORT_PMIC", null ],
      [ "Testing", "PORT.html#PORT_TESTING", null ],
      [ "Board IOCTL", "PORT.html#PORT_IOCTL", null ],
      [ "Debug", "PORT.html#PORT_DEBUG", [
        [ "Logging", "PORT.html#autotoc_md6", null ],
        [ "Debug Monitor", "PORT.html#autotoc_md7", null ],
        [ "JTAG", "PORT.html#autotoc_md8", null ],
        [ "SC WDOG", "PORT.html#PORT_DEBUG_WDOG", null ]
      ] ]
    ] ],
    [ "Reference Boards", "REF_BOARD.html", [
      [ "Image Compile", "REF_BOARD.html#REF_COMPILE", null ],
      [ "Board Initialization", "REF_BOARD.html#REF_INIT", null ],
      [ "Debug Output", "REF_BOARD.html#REF_DEBUG", null ],
      [ "System Configuration", "REF_BOARD.html#REF_CONFIG", [
        [ "Board Parameters", "REF_BOARD.html#autotoc_md9", null ],
        [ "Pad Configuration", "REF_BOARD.html#autotoc_md10", null ],
        [ "Resource Availability", "REF_BOARD.html#autotoc_md11", null ],
        [ "Resource Configuration", "REF_BOARD.html#autotoc_md12", null ],
        [ "SCU Resources", "REF_BOARD.html#autotoc_md13", null ],
        [ "Boot Resource Partitioning", "REF_BOARD.html#autotoc_md14", null ],
        [ "Early CPUs", "REF_BOARD.html#autotoc_md15", null ]
      ] ],
      [ "DDR Configuration", "REF_BOARD.html#BOARD_DDR", [
        [ "DDR Init by ROM", "REF_BOARD.html#autotoc_md16", null ],
        [ "DDR Init by SCFW", "REF_BOARD.html#autotoc_md17", null ],
        [ "DDR Configuration", "REF_BOARD.html#autotoc_md18", null ],
        [ "RPA Tool", "REF_BOARD.html#autotoc_md19", null ]
      ] ],
      [ "Power Management", "REF_BOARD.html#autotoc_md20", [
        [ "PMIC Temperature Sensors", "REF_BOARD.html#autotoc_md21", null ]
      ] ],
      [ "Reset and Fault Handling", "REF_BOARD.html#BOARD_FAULT", null ],
      [ "Button Handling", "REF_BOARD.html#BOARD_BUTTON", null ]
    ] ],
    [ "Usage", "USAGE.html", [
      [ "SCFW API", "USAGE.html#USAGE_SCFW", null ],
      [ "Loading", "USAGE.html#USAGE_LOADING", null ],
      [ "Boot Flags", "USAGE.html#BOOT_FLAGS", null ],
      [ "CPU Start Address", "USAGE.html#BOOT_ADDR", [
        [ "Cortex-A Start Address", "USAGE.html#autotoc_md22", null ],
        [ "Cortex-M Start Address", "USAGE.html#autotoc_md23", null ]
      ] ],
      [ "Cortex-M4 DDR Aliasing", "USAGE.html#M4_DDR_ALIAS", null ]
    ] ],
    [ "Resource Management", "RM_TH.html", [
      [ "Partitions", "RM_TH.html#RM_PT", null ],
      [ "Resources", "RM_TH.html#RM_RSRC", null ],
      [ "Pads", "RM_TH.html#RM_PAD", null ],
      [ "Memory Regions", "RM_TH.html#RM_MR", null ],
      [ "SCFW API", "RM_TH.html#RM_SAPI", null ],
      [ "Hardware Resource/Memory Isolation", "RM_TH.html#RM_HRMI", null ],
      [ "Example", "RM_TH.html#RM_EXP", null ]
    ] ],
    [ "Power Management", "PM_TH.html", [
      [ "Wake from Low Power", "PM_TH.html#PM_WAKE", [
        [ "Wake Event Sources", "PM_TH.html#autotoc_md24", null ],
        [ "GIC Wake Events", "PM_TH.html#autotoc_md25", null ],
        [ "IRQSTEER Wake Events", "PM_TH.html#autotoc_md26", null ],
        [ "SCU Wake Events", "PM_TH.html#autotoc_md27", null ],
        [ "Pad Wake Events", "PM_TH.html#autotoc_md28", null ]
      ] ],
      [ "System Power Off", "PM_TH.html#PM_SYS_OFF", null ],
      [ "Reset Control", "PM_TH.html#PM_RESET", null ]
    ] ],
    [ "Reset", "RESET.html", [
      [ "Board Design", "RESET.html#RESET_BD", null ],
      [ "CPU Reset", "RESET.html#RESET_CPU", null ],
      [ "Partition Reset", "RESET.html#RESET_PART", [
        [ "Partition Creation", "RESET.html#autotoc_md29", null ],
        [ "Partition Boot", "RESET.html#autotoc_md30", null ],
        [ "mkimage", "RESET.html#autotoc_md31", null ]
      ] ],
      [ "Board Reset", "RESET.html#RESET_BRD", null ],
      [ "Watchdog Reset", "RESET.html#RESET_WDOG", [
        [ "Typical Usage", "RESET.html#autotoc_md32", null ]
      ] ],
      [ "Reset Reason", "RESET.html#RESET_REASON", null ],
      [ "Notification", "RESET.html#autotoc_md33", null ],
      [ "AP Reset Scenarios", "RESET.html#autotoc_md34", null ],
      [ "Examples", "RESET.html#RESET_EXAMPLES", [
        [ "AP Independent from M4", "RESET.html#autotoc_md35", null ],
        [ "M4 Boots AP", "RESET.html#autotoc_md36", null ],
        [ "AP Boots M4", "RESET.html#autotoc_md37", null ]
      ] ]
    ] ],
    [ "Debug Monitor", "EXPORT_DEBUG_MONITOR.html", null ],
    [ "RPC Protocol", "PROTOCOL.html", [
      [ "Remote Procedure Call", "PROTOCOL.html#autotoc_md38", null ],
      [ "Inter-Processor Communication", "PROTOCOL.html#autotoc_md39", null ],
      [ "Interrupts", "PROTOCOL.html#autotoc_md40", [
        [ "SCFW to Client Interrupts", "PROTOCOL.html#autotoc_md41", [
          [ "Interrupt Service Request", "PROTOCOL.html#autotoc_md42", null ],
          [ "Cortex-M Wake", "PROTOCOL.html#autotoc_md43", null ],
          [ "Cold Boot Flag", "PROTOCOL.html#autotoc_md44", null ],
          [ "Cortex-M Debug Wake", "PROTOCOL.html#autotoc_md45", null ]
        ] ],
        [ "Client to SCFW Interrupts", "PROTOCOL.html#autotoc_md46", [
          [ "RPC/IPC Reset Request", "PROTOCOL.html#autotoc_md47", null ]
        ] ]
      ] ],
      [ "Flags/Status", "PROTOCOL.html#autotoc_md48", [
        [ "SCFW to Client Flags/Status", "PROTOCOL.html#autotoc_md49", null ]
      ] ],
      [ "Porting", "PROTOCOL.html#autotoc_md50", null ],
      [ "API Message Formats", "PROTOCOL.html#autotoc_md51", [
        [ "sc_pm_set_sys_power_mode()", "PROTOCOL.html#autotoc_md52", null ],
        [ "sc_pm_set_partition_power_mode()", "PROTOCOL.html#autotoc_md53", null ],
        [ "sc_pm_get_sys_power_mode()", "PROTOCOL.html#autotoc_md54", null ],
        [ "sc_pm_partition_wake()", "PROTOCOL.html#autotoc_md55", null ],
        [ "sc_pm_set_resource_power_mode()", "PROTOCOL.html#autotoc_md56", null ],
        [ "sc_pm_set_resource_power_mode_all()", "PROTOCOL.html#autotoc_md57", null ],
        [ "sc_pm_get_resource_power_mode()", "PROTOCOL.html#autotoc_md58", null ],
        [ "sc_pm_req_low_power_mode()", "PROTOCOL.html#autotoc_md59", null ],
        [ "sc_pm_req_cpu_low_power_mode()", "PROTOCOL.html#autotoc_md60", null ],
        [ "sc_pm_set_cpu_resume_addr()", "PROTOCOL.html#autotoc_md61", null ],
        [ "sc_pm_set_cpu_resume()", "PROTOCOL.html#autotoc_md62", null ],
        [ "sc_pm_req_sys_if_power_mode()", "PROTOCOL.html#autotoc_md63", null ],
        [ "sc_pm_set_clock_rate()", "PROTOCOL.html#autotoc_md64", null ],
        [ "sc_pm_get_clock_rate()", "PROTOCOL.html#autotoc_md65", null ],
        [ "sc_pm_clock_enable()", "PROTOCOL.html#autotoc_md66", null ],
        [ "sc_pm_set_clock_parent()", "PROTOCOL.html#autotoc_md67", null ],
        [ "sc_pm_get_clock_parent()", "PROTOCOL.html#autotoc_md68", null ],
        [ "sc_pm_reset()", "PROTOCOL.html#autotoc_md69", null ],
        [ "sc_pm_reset_reason()", "PROTOCOL.html#autotoc_md70", null ],
        [ "sc_pm_get_reset_part()", "PROTOCOL.html#autotoc_md71", null ],
        [ "sc_pm_boot()", "PROTOCOL.html#autotoc_md72", null ],
        [ "sc_pm_set_boot_parm()", "PROTOCOL.html#autotoc_md73", null ],
        [ "sc_pm_reboot()", "PROTOCOL.html#autotoc_md74", null ],
        [ "sc_pm_reboot_partition()", "PROTOCOL.html#autotoc_md75", null ],
        [ "sc_pm_reboot_continue()", "PROTOCOL.html#autotoc_md76", null ],
        [ "sc_pm_cpu_start()", "PROTOCOL.html#autotoc_md77", null ],
        [ "sc_pm_cpu_reset()", "PROTOCOL.html#autotoc_md78", null ],
        [ "sc_pm_resource_reset()", "PROTOCOL.html#autotoc_md79", null ],
        [ "sc_pm_is_partition_started()", "PROTOCOL.html#autotoc_md80", null ],
        [ "sc_rm_partition_alloc()", "PROTOCOL.html#autotoc_md81", null ],
        [ "sc_rm_set_confidential()", "PROTOCOL.html#autotoc_md82", null ],
        [ "sc_rm_partition_free()", "PROTOCOL.html#autotoc_md83", null ],
        [ "sc_rm_get_did()", "PROTOCOL.html#autotoc_md84", null ],
        [ "sc_rm_partition_static()", "PROTOCOL.html#autotoc_md85", null ],
        [ "sc_rm_partition_lock()", "PROTOCOL.html#autotoc_md86", null ],
        [ "sc_rm_get_partition()", "PROTOCOL.html#autotoc_md87", null ],
        [ "sc_rm_set_parent()", "PROTOCOL.html#autotoc_md88", null ],
        [ "sc_rm_move_all()", "PROTOCOL.html#autotoc_md89", null ],
        [ "sc_rm_assign_resource()", "PROTOCOL.html#autotoc_md90", null ],
        [ "sc_rm_set_resource_movable()", "PROTOCOL.html#autotoc_md91", null ],
        [ "sc_rm_set_subsys_rsrc_movable()", "PROTOCOL.html#autotoc_md92", null ],
        [ "sc_rm_set_master_attributes()", "PROTOCOL.html#autotoc_md93", null ],
        [ "sc_rm_set_master_sid()", "PROTOCOL.html#autotoc_md94", null ],
        [ "sc_rm_set_peripheral_permissions()", "PROTOCOL.html#autotoc_md95", null ],
        [ "sc_rm_is_resource_owned()", "PROTOCOL.html#autotoc_md96", null ],
        [ "sc_rm_get_resource_owner()", "PROTOCOL.html#autotoc_md97", null ],
        [ "sc_rm_is_resource_master()", "PROTOCOL.html#autotoc_md98", null ],
        [ "sc_rm_is_resource_peripheral()", "PROTOCOL.html#autotoc_md99", null ],
        [ "sc_rm_get_resource_info()", "PROTOCOL.html#autotoc_md100", null ],
        [ "sc_rm_memreg_alloc()", "PROTOCOL.html#autotoc_md101", null ],
        [ "sc_rm_memreg_split()", "PROTOCOL.html#autotoc_md102", null ],
        [ "sc_rm_memreg_frag()", "PROTOCOL.html#autotoc_md103", null ],
        [ "sc_rm_memreg_free()", "PROTOCOL.html#autotoc_md104", null ],
        [ "sc_rm_find_memreg()", "PROTOCOL.html#autotoc_md105", null ],
        [ "sc_rm_assign_memreg()", "PROTOCOL.html#autotoc_md106", null ],
        [ "sc_rm_set_memreg_permissions()", "PROTOCOL.html#autotoc_md107", null ],
        [ "sc_rm_set_memreg_iee()", "PROTOCOL.html#autotoc_md108", null ],
        [ "sc_rm_is_memreg_owned()", "PROTOCOL.html#autotoc_md109", null ],
        [ "sc_rm_get_memreg_info()", "PROTOCOL.html#autotoc_md110", null ],
        [ "sc_rm_assign_pad()", "PROTOCOL.html#autotoc_md111", null ],
        [ "sc_rm_set_pad_movable()", "PROTOCOL.html#autotoc_md112", null ],
        [ "sc_rm_is_pad_owned()", "PROTOCOL.html#autotoc_md113", null ],
        [ "sc_rm_dump()", "PROTOCOL.html#autotoc_md114", null ],
        [ "sc_timer_set_wdog_timeout()", "PROTOCOL.html#autotoc_md115", null ],
        [ "sc_timer_set_wdog_pre_timeout()", "PROTOCOL.html#autotoc_md116", null ],
        [ "sc_timer_set_wdog_window()", "PROTOCOL.html#autotoc_md117", null ],
        [ "sc_timer_start_wdog()", "PROTOCOL.html#autotoc_md118", null ],
        [ "sc_timer_stop_wdog()", "PROTOCOL.html#autotoc_md119", null ],
        [ "sc_timer_ping_wdog()", "PROTOCOL.html#autotoc_md120", null ],
        [ "sc_timer_get_wdog_status()", "PROTOCOL.html#autotoc_md121", null ],
        [ "sc_timer_pt_get_wdog_status()", "PROTOCOL.html#autotoc_md122", null ],
        [ "sc_timer_set_wdog_action()", "PROTOCOL.html#autotoc_md123", null ],
        [ "sc_timer_set_rtc_time()", "PROTOCOL.html#autotoc_md124", null ],
        [ "sc_timer_get_rtc_time()", "PROTOCOL.html#autotoc_md125", null ],
        [ "sc_timer_get_rtc_sec1970()", "PROTOCOL.html#autotoc_md126", null ],
        [ "sc_timer_set_rtc_alarm()", "PROTOCOL.html#autotoc_md127", null ],
        [ "sc_timer_set_rtc_periodic_alarm()", "PROTOCOL.html#autotoc_md128", null ],
        [ "sc_timer_cancel_rtc_alarm()", "PROTOCOL.html#autotoc_md129", null ],
        [ "sc_timer_set_rtc_calb()", "PROTOCOL.html#autotoc_md130", null ],
        [ "sc_timer_set_sysctr_alarm()", "PROTOCOL.html#autotoc_md131", null ],
        [ "sc_timer_set_sysctr_periodic_alarm()", "PROTOCOL.html#autotoc_md132", null ],
        [ "sc_timer_cancel_sysctr_alarm()", "PROTOCOL.html#autotoc_md133", null ],
        [ "sc_pad_set_mux()", "PROTOCOL.html#autotoc_md134", null ],
        [ "sc_pad_get_mux()", "PROTOCOL.html#autotoc_md135", null ],
        [ "sc_pad_set_gp()", "PROTOCOL.html#autotoc_md136", null ],
        [ "sc_pad_get_gp()", "PROTOCOL.html#autotoc_md137", null ],
        [ "sc_pad_set_wakeup()", "PROTOCOL.html#autotoc_md138", null ],
        [ "sc_pad_get_wakeup()", "PROTOCOL.html#autotoc_md139", null ],
        [ "sc_pad_set_all()", "PROTOCOL.html#autotoc_md140", null ],
        [ "sc_pad_get_all()", "PROTOCOL.html#autotoc_md141", null ],
        [ "sc_pad_set()", "PROTOCOL.html#autotoc_md142", null ],
        [ "sc_pad_get()", "PROTOCOL.html#autotoc_md143", null ],
        [ "sc_pad_config()", "PROTOCOL.html#autotoc_md144", null ],
        [ "sc_pad_set_gp_28fdsoi()", "PROTOCOL.html#autotoc_md145", null ],
        [ "sc_pad_get_gp_28fdsoi()", "PROTOCOL.html#autotoc_md146", null ],
        [ "sc_pad_set_gp_28fdsoi_hsic()", "PROTOCOL.html#autotoc_md147", null ],
        [ "sc_pad_get_gp_28fdsoi_hsic()", "PROTOCOL.html#autotoc_md148", null ],
        [ "sc_pad_set_gp_28fdsoi_comp()", "PROTOCOL.html#autotoc_md149", null ],
        [ "sc_pad_get_gp_28fdsoi_comp()", "PROTOCOL.html#autotoc_md150", null ],
        [ "sc_misc_set_control()", "PROTOCOL.html#autotoc_md151", null ],
        [ "sc_misc_get_control()", "PROTOCOL.html#autotoc_md152", null ],
        [ "sc_misc_set_max_dma_group()", "PROTOCOL.html#autotoc_md153", null ],
        [ "sc_misc_set_dma_group()", "PROTOCOL.html#autotoc_md154", null ],
        [ "sc_misc_debug_out()", "PROTOCOL.html#autotoc_md155", null ],
        [ "sc_misc_waveform_capture()", "PROTOCOL.html#autotoc_md156", null ],
        [ "sc_misc_build_info()", "PROTOCOL.html#autotoc_md157", null ],
        [ "sc_misc_api_ver()", "PROTOCOL.html#autotoc_md158", null ],
        [ "sc_misc_unique_id()", "PROTOCOL.html#autotoc_md159", null ],
        [ "sc_misc_set_ari()", "PROTOCOL.html#autotoc_md160", null ],
        [ "sc_misc_boot_status()", "PROTOCOL.html#autotoc_md161", null ],
        [ "sc_misc_boot_done()", "PROTOCOL.html#autotoc_md162", null ],
        [ "sc_misc_otp_fuse_read()", "PROTOCOL.html#autotoc_md163", null ],
        [ "sc_misc_otp_fuse_write()", "PROTOCOL.html#autotoc_md164", null ],
        [ "sc_misc_set_temp()", "PROTOCOL.html#autotoc_md165", null ],
        [ "sc_misc_get_temp()", "PROTOCOL.html#autotoc_md166", null ],
        [ "sc_misc_get_boot_dev()", "PROTOCOL.html#autotoc_md167", null ],
        [ "sc_misc_get_boot_type()", "PROTOCOL.html#autotoc_md168", null ],
        [ "sc_misc_get_boot_container()", "PROTOCOL.html#autotoc_md169", null ],
        [ "sc_misc_get_button_status()", "PROTOCOL.html#autotoc_md170", null ],
        [ "sc_misc_rompatch_checksum()", "PROTOCOL.html#autotoc_md171", null ],
        [ "sc_misc_board_ioctl()", "PROTOCOL.html#autotoc_md172", null ],
        [ "sc_seco_image_load()", "PROTOCOL.html#autotoc_md173", null ],
        [ "sc_seco_authenticate()", "PROTOCOL.html#autotoc_md174", null ],
        [ "sc_seco_enh_authenticate()", "PROTOCOL.html#autotoc_md175", null ],
        [ "sc_seco_forward_lifecycle()", "PROTOCOL.html#autotoc_md176", null ],
        [ "sc_seco_return_lifecycle()", "PROTOCOL.html#autotoc_md177", null ],
        [ "sc_seco_commit()", "PROTOCOL.html#autotoc_md178", null ],
        [ "sc_seco_attest_mode()", "PROTOCOL.html#autotoc_md179", null ],
        [ "sc_seco_attest()", "PROTOCOL.html#autotoc_md180", null ],
        [ "sc_seco_get_attest_pkey()", "PROTOCOL.html#autotoc_md181", null ],
        [ "sc_seco_get_attest_sign()", "PROTOCOL.html#autotoc_md182", null ],
        [ "sc_seco_attest_verify()", "PROTOCOL.html#autotoc_md183", null ],
        [ "sc_seco_gen_key_blob()", "PROTOCOL.html#autotoc_md184", null ],
        [ "sc_seco_load_key()", "PROTOCOL.html#autotoc_md185", null ],
        [ "sc_seco_get_mp_key()", "PROTOCOL.html#autotoc_md186", null ],
        [ "sc_seco_update_mpmr()", "PROTOCOL.html#autotoc_md187", null ],
        [ "sc_seco_get_mp_sign()", "PROTOCOL.html#autotoc_md188", null ],
        [ "sc_seco_build_info()", "PROTOCOL.html#autotoc_md189", null ],
        [ "sc_seco_chip_info()", "PROTOCOL.html#autotoc_md190", null ],
        [ "sc_seco_enable_debug()", "PROTOCOL.html#autotoc_md191", null ],
        [ "sc_seco_get_event()", "PROTOCOL.html#autotoc_md192", null ],
        [ "sc_seco_fuse_write()", "PROTOCOL.html#autotoc_md193", null ],
        [ "sc_seco_patch()", "PROTOCOL.html#autotoc_md194", null ],
        [ "sc_seco_set_mono_counter_partition()", "PROTOCOL.html#autotoc_md195", null ],
        [ "sc_seco_set_fips_mode()", "PROTOCOL.html#autotoc_md196", null ],
        [ "sc_seco_start_rng()", "PROTOCOL.html#autotoc_md197", null ],
        [ "sc_seco_sab_msg()", "PROTOCOL.html#autotoc_md198", null ],
        [ "sc_seco_secvio_enable()", "PROTOCOL.html#autotoc_md199", null ],
        [ "sc_seco_secvio_config()", "PROTOCOL.html#autotoc_md200", null ],
        [ "sc_seco_secvio_dgo_config()", "PROTOCOL.html#autotoc_md201", null ],
        [ "sc_irq_enable()", "PROTOCOL.html#autotoc_md202", null ],
        [ "sc_irq_status()", "PROTOCOL.html#autotoc_md203", null ]
      ] ]
    ] ],
    [ "Driver errors status", "drv_err.html", null ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ],
    [ "Examples", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"DISCLAIMER.html",
"USAGE.html#BOOT_FLAGS",
"group__BRD__SVC.html#ga9b55472b7f9f36040cc840df7f3786e1",
"group__INF__SS.html#gace8a58c5f330b3672302adfe5d740c92",
"group__MISC__SVC.html#gabdd37acbd9c11137fb7b28849b9d58a0",
"group__PM__SVC.html#ga332022459db1c91c85a658efc58dbdad",
"group__RM__SVC.html#ga219e2151d8dd2d99ae71835a97848bf3",
"group__SECO__SVC.html#ga262782d4b20452da27b8389af8c5e531",
"group__SOC.html#ga92caab2808650e2983de1278093e42ca",
"group__gpio__driver.html#gaa1deaff6764df2649453fa5502ee0fcc",
"group__lpi2c__slave__driver.html#gadf34085d4557ceb3081fff9fe0e3189a",
"group__pca6416a__driver.html#ga915626364e0b97fb4f487654a5e1e723",
"group__rgpio__driver.html#ga9f909f004905ecb6b041578ae4d76bc7",
"group__snvs__driver.html#ga918c3f03745b792f5b42764bfeaea793",
"structlpuart__config__t.html#a58ce25b71bde98b9c09875481637d120",
"types_8h.html#a0db5d1a426a7163fb072ef989ae7345d",
"types_8h.html#a5aa99298d7332102d64922f8cb8de583",
"types_8h.html#aae7d3b84459eacb8c1fc07f6e83c48b9"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';