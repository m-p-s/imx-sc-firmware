var structsc__rsrc__map__t =
[
    [ "resource", "structsc__rsrc__map__t.html#a6ddb01c96abced2a94651e164b1c89f3", null ],
    [ "ss_idx", "structsc__rsrc__map__t.html#a15e6c67754d4baefc65e7cdc2e391136", null ],
    [ "inst", "structsc__rsrc__map__t.html#a3318c158d898cb2eb4cca6478388418c", null ]
];