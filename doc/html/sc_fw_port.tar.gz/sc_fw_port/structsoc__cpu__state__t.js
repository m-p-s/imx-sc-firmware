var structsoc__cpu__state__t =
[
    [ "rm_idx", "structsoc__cpu__state__t.html#a9e7a2ca25d955a971a106333a49bdcb6", null ],
    [ "req_mode", "structsoc__cpu__state__t.html#aaafc4c090e129483d7ab04531487b00d", null ],
    [ "lpm_active", "structsoc__cpu__state__t.html#a267c5339bc84cd369007c40a5e3ce7a4", null ],
    [ "rst_req", "structsoc__cpu__state__t.html#a78edc942856341f9680a12eec468f18b", null ],
    [ "early_wake", "structsoc__cpu__state__t.html#a0117c8bf810513b99ca15fd264fcba95", null ],
    [ "wake_idx", "structsoc__cpu__state__t.html#a40a8de2572be7fb88459d53cd64e0933", null ],
    [ "wake_src", "structsoc__cpu__state__t.html#a83ada33a4d22cb585959fcb254f45fab", null ],
    [ "resume_addr", "structsoc__cpu__state__t.html#ab878d20368516acb6f45698840b8da5f", null ]
];