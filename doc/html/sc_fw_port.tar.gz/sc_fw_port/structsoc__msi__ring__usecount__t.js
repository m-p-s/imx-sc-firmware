var structsoc__msi__ring__usecount__t =
[
    [ "rsrc", "structsoc__msi__ring__usecount__t.html#a054ed0a9e219c63ef253c55300a57536", null ],
    [ "count", "structsoc__msi__ring__usecount__t.html#ad01f8b5e4ec3b40ed714e8d08de9a45b", null ],
    [ "ss_count", "structsoc__msi__ring__usecount__t.html#a7796a5f74f249b7604e0ad8e123eee73", null ]
];