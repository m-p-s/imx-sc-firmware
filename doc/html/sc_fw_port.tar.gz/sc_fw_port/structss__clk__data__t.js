var structss__clk__data__t =
[
    [ "usecount", "structss__clk__data__t.html#ae25f401fe141b83927a94053367388e7", null ],
    [ "cur_mode", "structss__clk__data__t.html#a56f0268a26e5c9ffe5567f3ab7568aaf", null ],
    [ "parent", "structss__clk__data__t.html#aff8a04fc6915e213302b1fb7be891737", null ],
    [ "rate_div", "structss__clk__data__t.html#a18b5f2e60a16ae8f5cf559174efcecfd", null ],
    [ "parent_rate", "structss__clk__data__t.html#a2103004d3b627a25807883a099eca7f1", null ]
];