var structsoc__sys__if__node__t =
[
    [ "num_rm_idx", "structsoc__sys__if__node__t.html#a72ee6009d3eb0dcc6b110e4a7d255bd8", null ],
    [ "rsrc", "structsoc__sys__if__node__t.html#a94c26a9d98def3c0c88e83a75af0d164", null ],
    [ "rm_idx", "structsoc__sys__if__node__t.html#a56a4c54ec182ae381da2780a31429052", null ],
    [ "saved_pm", "structsoc__sys__if__node__t.html#a3d22405ab0908579e33e7b9013452827", null ]
];