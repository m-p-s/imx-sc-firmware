var struct__lpuart__handle =
[
    [ "txData", "struct__lpuart__handle.html#a85dfd2cc5aa30f259ce7338a48c832a8", null ],
    [ "txDataSize", "struct__lpuart__handle.html#a2114edec74578fe798a62cf852ab0194", null ],
    [ "txDataSizeAll", "struct__lpuart__handle.html#a84153c9f581e7201d5c2a20423a321da", null ],
    [ "rxData", "struct__lpuart__handle.html#a6d3fceca5b3bee7f183116ee7b3a3b93", null ],
    [ "rxDataSize", "struct__lpuart__handle.html#a6b9d688ed6ecbb3b71d6b266bec66edb", null ],
    [ "rxDataSizeAll", "struct__lpuart__handle.html#a4ac2cb3c691238ed65a34410ab8f2920", null ],
    [ "rxRingBuffer", "struct__lpuart__handle.html#a3eca0396fcb49d3652a40c7cf49024c8", null ],
    [ "rxRingBufferSize", "struct__lpuart__handle.html#a12cff540159d2fb592e4856957d820cd", null ],
    [ "rxRingBufferHead", "struct__lpuart__handle.html#aaffed28a2a686bb90e3238a3d8e597b3", null ],
    [ "rxRingBufferTail", "struct__lpuart__handle.html#acecaaa5df8327c5b33815cb7483abd75", null ],
    [ "callback", "struct__lpuart__handle.html#a881c1d7231d1ee0bcb3eb5f1447f75a4", null ],
    [ "userData", "struct__lpuart__handle.html#ad9f3989cffe26d3ca63d381da36024be", null ],
    [ "txState", "struct__lpuart__handle.html#a86fe3c8f354afbe67d28a71068206b26", null ],
    [ "rxState", "struct__lpuart__handle.html#a088a1e9a009d852b90fb8390fa7cbbcd", null ]
];