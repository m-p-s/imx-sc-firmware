/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2019 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as published by
the Free Software Foundation

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "System Controller Firmware API Reference Guide", "index.html", [
    [ "Overview", "index.html", [
      [ "System Initialization and Boot", "index.html#INIT_SEC", null ],
      [ "System Controller Communication", "index.html#SCC_SEC", null ],
      [ "System Controller Services", "index.html#SCFS_SEC", [
        [ "Power Management Service", "index.html#PM_SEC", null ],
        [ "Resource Management Service", "index.html#RM_SEC", null ],
        [ "Pad Configuration Service", "index.html#PAD_SEC", null ],
        [ "Timer Service", "index.html#TIMER_SEC", null ],
        [ "Interrupt Service", "index.html#IRQ_SEC", null ],
        [ "Security Service", "index.html#SECO_SEC", null ],
        [ "Miscellaneous Service", "index.html#MISC_SEC", null ]
      ] ]
    ] ],
    [ "Disclaimer", "DISCLAIMER.html", null ],
    [ "Usage", "USAGE.html", [
      [ "SCFW API", "USAGE.html#USAGE_SCFW", null ],
      [ "Loading", "USAGE.html#USAGE_LOADING", null ],
      [ "Boot Flags", "USAGE.html#BOOT_FLAGS", null ],
      [ "CPU Start Address", "USAGE.html#BOOT_ADDR", [
        [ "Cortex-A Start Address", "USAGE.html#autotoc_md0", null ],
        [ "Cortex-M Start Address", "USAGE.html#autotoc_md1", null ]
      ] ],
      [ "Cortex-M4 DDR Aliasing", "USAGE.html#M4_DDR_ALIAS", null ]
    ] ],
    [ "Resource Management", "RM_TH.html", [
      [ "Partitions", "RM_TH.html#RM_PT", null ],
      [ "Resources", "RM_TH.html#RM_RSRC", null ],
      [ "Pads", "RM_TH.html#RM_PAD", null ],
      [ "Memory Regions", "RM_TH.html#RM_MR", null ],
      [ "SCFW API", "RM_TH.html#RM_SAPI", null ],
      [ "Hardware Resource/Memory Isolation", "RM_TH.html#RM_HRMI", null ],
      [ "Example", "RM_TH.html#RM_EXP", null ]
    ] ],
    [ "Power Management", "PM_TH.html", [
      [ "Wake from Low Power", "PM_TH.html#PM_WAKE", [
        [ "Wake Event Sources", "PM_TH.html#autotoc_md2", null ],
        [ "GIC Wake Events", "PM_TH.html#autotoc_md3", null ],
        [ "IRQSTEER Wake Events", "PM_TH.html#autotoc_md4", null ],
        [ "SCU Wake Events", "PM_TH.html#autotoc_md5", null ],
        [ "Pad Wake Events", "PM_TH.html#autotoc_md6", null ]
      ] ],
      [ "System Power Off", "PM_TH.html#PM_SYS_OFF", null ],
      [ "Reset Control", "PM_TH.html#PM_RESET", null ]
    ] ],
    [ "Resource List", "RESOURCES.html", null ],
    [ "Clock List", "CLOCKS.html", null ],
    [ "Control List", "CONTROLS.html", null ],
    [ "Pad List", "PADS.html", null ],
    [ "RPC Protocol", "PROTOCOL.html", [
      [ "Remote Procedure Call", "PROTOCOL.html#autotoc_md7", null ],
      [ "Inter-Processor Communication", "PROTOCOL.html#autotoc_md8", null ],
      [ "Interrupts", "PROTOCOL.html#autotoc_md9", [
        [ "SCFW to Client Interrupts", "PROTOCOL.html#autotoc_md10", [
          [ "Interrupt Service Request", "PROTOCOL.html#autotoc_md11", null ],
          [ "Cortex-M Wake", "PROTOCOL.html#autotoc_md12", null ],
          [ "Cold Boot Flag", "PROTOCOL.html#autotoc_md13", null ],
          [ "Cortex-M Debug Wake", "PROTOCOL.html#autotoc_md14", null ]
        ] ],
        [ "Client to SCFW Interrupts", "PROTOCOL.html#autotoc_md15", [
          [ "RPC/IPC Reset Request", "PROTOCOL.html#autotoc_md16", null ]
        ] ]
      ] ],
      [ "Flags/Status", "PROTOCOL.html#autotoc_md17", [
        [ "SCFW to Client Flags/Status", "PROTOCOL.html#autotoc_md18", null ]
      ] ],
      [ "Porting", "PROTOCOL.html#autotoc_md19", null ],
      [ "API Message Formats", "PROTOCOL.html#autotoc_md20", [
        [ "sc_pm_set_sys_power_mode()", "PROTOCOL.html#autotoc_md21", null ],
        [ "sc_pm_set_partition_power_mode()", "PROTOCOL.html#autotoc_md22", null ],
        [ "sc_pm_get_sys_power_mode()", "PROTOCOL.html#autotoc_md23", null ],
        [ "sc_pm_partition_wake()", "PROTOCOL.html#autotoc_md24", null ],
        [ "sc_pm_set_resource_power_mode()", "PROTOCOL.html#autotoc_md25", null ],
        [ "sc_pm_set_resource_power_mode_all()", "PROTOCOL.html#autotoc_md26", null ],
        [ "sc_pm_get_resource_power_mode()", "PROTOCOL.html#autotoc_md27", null ],
        [ "sc_pm_req_low_power_mode()", "PROTOCOL.html#autotoc_md28", null ],
        [ "sc_pm_req_cpu_low_power_mode()", "PROTOCOL.html#autotoc_md29", null ],
        [ "sc_pm_set_cpu_resume_addr()", "PROTOCOL.html#autotoc_md30", null ],
        [ "sc_pm_set_cpu_resume()", "PROTOCOL.html#autotoc_md31", null ],
        [ "sc_pm_req_sys_if_power_mode()", "PROTOCOL.html#autotoc_md32", null ],
        [ "sc_pm_set_clock_rate()", "PROTOCOL.html#autotoc_md33", null ],
        [ "sc_pm_get_clock_rate()", "PROTOCOL.html#autotoc_md34", null ],
        [ "sc_pm_clock_enable()", "PROTOCOL.html#autotoc_md35", null ],
        [ "sc_pm_set_clock_parent()", "PROTOCOL.html#autotoc_md36", null ],
        [ "sc_pm_get_clock_parent()", "PROTOCOL.html#autotoc_md37", null ],
        [ "sc_pm_reset()", "PROTOCOL.html#autotoc_md38", null ],
        [ "sc_pm_reset_reason()", "PROTOCOL.html#autotoc_md39", null ],
        [ "sc_pm_get_reset_part()", "PROTOCOL.html#autotoc_md40", null ],
        [ "sc_pm_boot()", "PROTOCOL.html#autotoc_md41", null ],
        [ "sc_pm_set_boot_parm()", "PROTOCOL.html#autotoc_md42", null ],
        [ "sc_pm_reboot()", "PROTOCOL.html#autotoc_md43", null ],
        [ "sc_pm_reboot_partition()", "PROTOCOL.html#autotoc_md44", null ],
        [ "sc_pm_reboot_continue()", "PROTOCOL.html#autotoc_md45", null ],
        [ "sc_pm_cpu_start()", "PROTOCOL.html#autotoc_md46", null ],
        [ "sc_pm_cpu_reset()", "PROTOCOL.html#autotoc_md47", null ],
        [ "sc_pm_resource_reset()", "PROTOCOL.html#autotoc_md48", null ],
        [ "sc_pm_is_partition_started()", "PROTOCOL.html#autotoc_md49", null ],
        [ "sc_rm_partition_alloc()", "PROTOCOL.html#autotoc_md50", null ],
        [ "sc_rm_set_confidential()", "PROTOCOL.html#autotoc_md51", null ],
        [ "sc_rm_partition_free()", "PROTOCOL.html#autotoc_md52", null ],
        [ "sc_rm_get_did()", "PROTOCOL.html#autotoc_md53", null ],
        [ "sc_rm_partition_static()", "PROTOCOL.html#autotoc_md54", null ],
        [ "sc_rm_partition_lock()", "PROTOCOL.html#autotoc_md55", null ],
        [ "sc_rm_get_partition()", "PROTOCOL.html#autotoc_md56", null ],
        [ "sc_rm_set_parent()", "PROTOCOL.html#autotoc_md57", null ],
        [ "sc_rm_move_all()", "PROTOCOL.html#autotoc_md58", null ],
        [ "sc_rm_assign_resource()", "PROTOCOL.html#autotoc_md59", null ],
        [ "sc_rm_set_resource_movable()", "PROTOCOL.html#autotoc_md60", null ],
        [ "sc_rm_set_subsys_rsrc_movable()", "PROTOCOL.html#autotoc_md61", null ],
        [ "sc_rm_set_master_attributes()", "PROTOCOL.html#autotoc_md62", null ],
        [ "sc_rm_set_master_sid()", "PROTOCOL.html#autotoc_md63", null ],
        [ "sc_rm_set_peripheral_permissions()", "PROTOCOL.html#autotoc_md64", null ],
        [ "sc_rm_is_resource_owned()", "PROTOCOL.html#autotoc_md65", null ],
        [ "sc_rm_get_resource_owner()", "PROTOCOL.html#autotoc_md66", null ],
        [ "sc_rm_is_resource_master()", "PROTOCOL.html#autotoc_md67", null ],
        [ "sc_rm_is_resource_peripheral()", "PROTOCOL.html#autotoc_md68", null ],
        [ "sc_rm_get_resource_info()", "PROTOCOL.html#autotoc_md69", null ],
        [ "sc_rm_memreg_alloc()", "PROTOCOL.html#autotoc_md70", null ],
        [ "sc_rm_memreg_split()", "PROTOCOL.html#autotoc_md71", null ],
        [ "sc_rm_memreg_frag()", "PROTOCOL.html#autotoc_md72", null ],
        [ "sc_rm_memreg_free()", "PROTOCOL.html#autotoc_md73", null ],
        [ "sc_rm_find_memreg()", "PROTOCOL.html#autotoc_md74", null ],
        [ "sc_rm_assign_memreg()", "PROTOCOL.html#autotoc_md75", null ],
        [ "sc_rm_set_memreg_permissions()", "PROTOCOL.html#autotoc_md76", null ],
        [ "sc_rm_set_memreg_iee()", "PROTOCOL.html#autotoc_md77", null ],
        [ "sc_rm_is_memreg_owned()", "PROTOCOL.html#autotoc_md78", null ],
        [ "sc_rm_get_memreg_info()", "PROTOCOL.html#autotoc_md79", null ],
        [ "sc_rm_assign_pad()", "PROTOCOL.html#autotoc_md80", null ],
        [ "sc_rm_set_pad_movable()", "PROTOCOL.html#autotoc_md81", null ],
        [ "sc_rm_is_pad_owned()", "PROTOCOL.html#autotoc_md82", null ],
        [ "sc_rm_dump()", "PROTOCOL.html#autotoc_md83", null ],
        [ "sc_timer_set_wdog_timeout()", "PROTOCOL.html#autotoc_md84", null ],
        [ "sc_timer_set_wdog_pre_timeout()", "PROTOCOL.html#autotoc_md85", null ],
        [ "sc_timer_set_wdog_window()", "PROTOCOL.html#autotoc_md86", null ],
        [ "sc_timer_start_wdog()", "PROTOCOL.html#autotoc_md87", null ],
        [ "sc_timer_stop_wdog()", "PROTOCOL.html#autotoc_md88", null ],
        [ "sc_timer_ping_wdog()", "PROTOCOL.html#autotoc_md89", null ],
        [ "sc_timer_get_wdog_status()", "PROTOCOL.html#autotoc_md90", null ],
        [ "sc_timer_pt_get_wdog_status()", "PROTOCOL.html#autotoc_md91", null ],
        [ "sc_timer_set_wdog_action()", "PROTOCOL.html#autotoc_md92", null ],
        [ "sc_timer_set_rtc_time()", "PROTOCOL.html#autotoc_md93", null ],
        [ "sc_timer_get_rtc_time()", "PROTOCOL.html#autotoc_md94", null ],
        [ "sc_timer_get_rtc_sec1970()", "PROTOCOL.html#autotoc_md95", null ],
        [ "sc_timer_set_rtc_alarm()", "PROTOCOL.html#autotoc_md96", null ],
        [ "sc_timer_set_rtc_periodic_alarm()", "PROTOCOL.html#autotoc_md97", null ],
        [ "sc_timer_cancel_rtc_alarm()", "PROTOCOL.html#autotoc_md98", null ],
        [ "sc_timer_set_rtc_calb()", "PROTOCOL.html#autotoc_md99", null ],
        [ "sc_timer_set_sysctr_alarm()", "PROTOCOL.html#autotoc_md100", null ],
        [ "sc_timer_set_sysctr_periodic_alarm()", "PROTOCOL.html#autotoc_md101", null ],
        [ "sc_timer_cancel_sysctr_alarm()", "PROTOCOL.html#autotoc_md102", null ],
        [ "sc_pad_set_mux()", "PROTOCOL.html#autotoc_md103", null ],
        [ "sc_pad_get_mux()", "PROTOCOL.html#autotoc_md104", null ],
        [ "sc_pad_set_gp()", "PROTOCOL.html#autotoc_md105", null ],
        [ "sc_pad_get_gp()", "PROTOCOL.html#autotoc_md106", null ],
        [ "sc_pad_set_wakeup()", "PROTOCOL.html#autotoc_md107", null ],
        [ "sc_pad_get_wakeup()", "PROTOCOL.html#autotoc_md108", null ],
        [ "sc_pad_set_all()", "PROTOCOL.html#autotoc_md109", null ],
        [ "sc_pad_get_all()", "PROTOCOL.html#autotoc_md110", null ],
        [ "sc_pad_set()", "PROTOCOL.html#autotoc_md111", null ],
        [ "sc_pad_get()", "PROTOCOL.html#autotoc_md112", null ],
        [ "sc_pad_config()", "PROTOCOL.html#autotoc_md113", null ],
        [ "sc_pad_set_gp_28fdsoi()", "PROTOCOL.html#autotoc_md114", null ],
        [ "sc_pad_get_gp_28fdsoi()", "PROTOCOL.html#autotoc_md115", null ],
        [ "sc_pad_set_gp_28fdsoi_hsic()", "PROTOCOL.html#autotoc_md116", null ],
        [ "sc_pad_get_gp_28fdsoi_hsic()", "PROTOCOL.html#autotoc_md117", null ],
        [ "sc_pad_set_gp_28fdsoi_comp()", "PROTOCOL.html#autotoc_md118", null ],
        [ "sc_pad_get_gp_28fdsoi_comp()", "PROTOCOL.html#autotoc_md119", null ],
        [ "sc_misc_set_control()", "PROTOCOL.html#autotoc_md120", null ],
        [ "sc_misc_get_control()", "PROTOCOL.html#autotoc_md121", null ],
        [ "sc_misc_set_max_dma_group()", "PROTOCOL.html#autotoc_md122", null ],
        [ "sc_misc_set_dma_group()", "PROTOCOL.html#autotoc_md123", null ],
        [ "sc_misc_debug_out()", "PROTOCOL.html#autotoc_md124", null ],
        [ "sc_misc_waveform_capture()", "PROTOCOL.html#autotoc_md125", null ],
        [ "sc_misc_build_info()", "PROTOCOL.html#autotoc_md126", null ],
        [ "sc_misc_api_ver()", "PROTOCOL.html#autotoc_md127", null ],
        [ "sc_misc_unique_id()", "PROTOCOL.html#autotoc_md128", null ],
        [ "sc_misc_set_ari()", "PROTOCOL.html#autotoc_md129", null ],
        [ "sc_misc_boot_status()", "PROTOCOL.html#autotoc_md130", null ],
        [ "sc_misc_boot_done()", "PROTOCOL.html#autotoc_md131", null ],
        [ "sc_misc_otp_fuse_read()", "PROTOCOL.html#autotoc_md132", null ],
        [ "sc_misc_otp_fuse_write()", "PROTOCOL.html#autotoc_md133", null ],
        [ "sc_misc_set_temp()", "PROTOCOL.html#autotoc_md134", null ],
        [ "sc_misc_get_temp()", "PROTOCOL.html#autotoc_md135", null ],
        [ "sc_misc_get_boot_dev()", "PROTOCOL.html#autotoc_md136", null ],
        [ "sc_misc_get_boot_type()", "PROTOCOL.html#autotoc_md137", null ],
        [ "sc_misc_get_boot_container()", "PROTOCOL.html#autotoc_md138", null ],
        [ "sc_misc_get_button_status()", "PROTOCOL.html#autotoc_md139", null ],
        [ "sc_misc_rompatch_checksum()", "PROTOCOL.html#autotoc_md140", null ],
        [ "sc_misc_board_ioctl()", "PROTOCOL.html#autotoc_md141", null ],
        [ "sc_seco_image_load()", "PROTOCOL.html#autotoc_md142", null ],
        [ "sc_seco_authenticate()", "PROTOCOL.html#autotoc_md143", null ],
        [ "sc_seco_enh_authenticate()", "PROTOCOL.html#autotoc_md144", null ],
        [ "sc_seco_forward_lifecycle()", "PROTOCOL.html#autotoc_md145", null ],
        [ "sc_seco_return_lifecycle()", "PROTOCOL.html#autotoc_md146", null ],
        [ "sc_seco_commit()", "PROTOCOL.html#autotoc_md147", null ],
        [ "sc_seco_attest_mode()", "PROTOCOL.html#autotoc_md148", null ],
        [ "sc_seco_attest()", "PROTOCOL.html#autotoc_md149", null ],
        [ "sc_seco_get_attest_pkey()", "PROTOCOL.html#autotoc_md150", null ],
        [ "sc_seco_get_attest_sign()", "PROTOCOL.html#autotoc_md151", null ],
        [ "sc_seco_attest_verify()", "PROTOCOL.html#autotoc_md152", null ],
        [ "sc_seco_gen_key_blob()", "PROTOCOL.html#autotoc_md153", null ],
        [ "sc_seco_load_key()", "PROTOCOL.html#autotoc_md154", null ],
        [ "sc_seco_get_mp_key()", "PROTOCOL.html#autotoc_md155", null ],
        [ "sc_seco_update_mpmr()", "PROTOCOL.html#autotoc_md156", null ],
        [ "sc_seco_get_mp_sign()", "PROTOCOL.html#autotoc_md157", null ],
        [ "sc_seco_build_info()", "PROTOCOL.html#autotoc_md158", null ],
        [ "sc_seco_chip_info()", "PROTOCOL.html#autotoc_md159", null ],
        [ "sc_seco_enable_debug()", "PROTOCOL.html#autotoc_md160", null ],
        [ "sc_seco_get_event()", "PROTOCOL.html#autotoc_md161", null ],
        [ "sc_seco_fuse_write()", "PROTOCOL.html#autotoc_md162", null ],
        [ "sc_seco_patch()", "PROTOCOL.html#autotoc_md163", null ],
        [ "sc_seco_set_mono_counter_partition()", "PROTOCOL.html#autotoc_md164", null ],
        [ "sc_seco_set_fips_mode()", "PROTOCOL.html#autotoc_md165", null ],
        [ "sc_seco_start_rng()", "PROTOCOL.html#autotoc_md166", null ],
        [ "sc_seco_sab_msg()", "PROTOCOL.html#autotoc_md167", null ],
        [ "sc_seco_secvio_enable()", "PROTOCOL.html#autotoc_md168", null ],
        [ "sc_seco_secvio_config()", "PROTOCOL.html#autotoc_md169", null ],
        [ "sc_seco_secvio_dgo_config()", "PROTOCOL.html#autotoc_md170", null ],
        [ "sc_irq_enable()", "PROTOCOL.html#autotoc_md171", null ],
        [ "sc_irq_status()", "PROTOCOL.html#autotoc_md172", null ]
      ] ]
    ] ],
    [ "Modules", "modules.html", "modules" ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"CLOCKS.html",
"group__IRQ__SVC.html#ga66b22b89b2fabc58867f7499986e3819",
"group__PAD__SVC.html#gadbff9e421da725e6065b903b8ce2c460",
"group__RM__SVC.html#ga64728691b1f53639709e1847ffaa0dc3",
"pads_8h.html#a18bf9a9446ed65a1fa6cc876b34210b0",
"pads_8h.html#afe7511ec761ff86721d32bfe6a540a4d",
"types_8h.html#a4c53f343cccdc8c6f43092c43392c159",
"types_8h.html#aa25a366c0aa9f4e23cf1639d633f4267",
"types_8h.html#af95f7726ad231eebd0c477e3fedc16e4"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';