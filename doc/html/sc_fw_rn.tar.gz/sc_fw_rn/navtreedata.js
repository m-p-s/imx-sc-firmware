/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2019 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as published by
the Free Software Foundation

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "System Controller Firmware Release Notes", "index.html", [
    [ "Introduction", "index.html", [
      [ "Highlights", "index.html#RN_HIGH", null ]
    ] ],
    [ "Change List", "RN_CL.html", [
      [ "SCFW 2020Q2 Patch 1 Change List", "RN_CL.html#RN_P1", [
        [ "Bug", "RN_CL.html#RN_CL_BUG1", null ]
      ] ],
      [ "Prior SCFW 2020Q2 Change List", "RN_CL.html#RN_P0", [
        [ "New Feature", "RN_CL.html#RN_CL_NEW", null ],
        [ "Improvement", "RN_CL.html#RN_CL_IMP", null ],
        [ "Bug", "RN_CL.html#RN_CL_BUG", null ],
        [ "Silicon Workaround", "RN_CL.html#RN_CL_REQ", null ],
        [ "Documentation", "RN_CL.html#RN_CL_DOC", null ]
      ] ],
      [ "Details", "RN_CL.html#CL_DETAIL", [
        [ "SCF-511: Add debug monitor command to dump clock config options", "RN_CL.html#RN_DETAIL_SCF_511", null ],
        [ "SCF-560: Add spread spectrum support for PCIe", "RN_CL.html#RN_DETAIL_SCF_560", null ],
        [ "SCF-580: Several CPU PM related functions not bound to only the CPU (M4 related) resource", "RN_CL.html#RN_DETAIL_SCF_580", null ],
        [ "SCF-582: Initialize VDD_MEMC usage count for SCFW unit test", "RN_CL.html#RN_DETAIL_SCF_582", null ],
        [ "SCF-584: i.MX8DXL EVK board bus expander reset controls incorrect", "RN_CL.html#RN_DETAIL_SCF_584", null ],
        [ "SCF-602: Add API to configure memory region IEE parameters", "RN_CL.html#RN_DETAIL_SCF_602", null ],
        [ "SCF-604: Add test for measuring the OSC 24MHz locking time", "RN_CL.html#RN_DETAIL_SCF_604", null ],
        [ "SCF-608: Move FLEXCAN0 and 1 signals to AP as used for SAI", "RN_CL.html#RN_DETAIL_SCF_608", null ],
        [ "SCF-617: Add support for fine tuning the audio PLL rate", "RN_CL.html#RN_DETAIL_SCF_617", null ],
        [ "SCF-621: Incorrect pad width in sc_rm_is_pad_owned() RPC implementation", "RN_CL.html#RN_DETAIL_SCF_621", null ],
        [ "SCF-628: Add control to enable MLB bandgap reference", "RN_CL.html#RN_DETAIL_SCF_628", null ]
      ] ]
    ] ],
    [ "Known Issues", "RN_KN.html", [
      [ "New Feature", "RN_KN.html#RN_KN_NEW", null ],
      [ "Improvement", "RN_KN.html#RN_KN_IMP", null ]
    ] ],
    [ "Additional Notes", "RN_ADD.html", [
      [ "General", "RN_ADD.html#RN_ADD_GEN", null ],
      [ "SCFW API Changes", "RN_ADD.html#RN_ADD_API", [
        [ "Interrupt (IRQ) Service", "RN_ADD.html#autotoc_md0", null ],
        [ "Miscellaneous (MISC) Service Changes", "RN_ADD.html#autotoc_md1", null ],
        [ "Pad Service Changes", "RN_ADD.html#autotoc_md2", null ],
        [ "Power Management (PM) Service", "RN_ADD.html#autotoc_md3", null ],
        [ "Resource Management (RM) Service", "RN_ADD.html#autotoc_md4", null ],
        [ "SECO Service Changes", "RN_ADD.html#autotoc_md5", null ],
        [ "Timer Service Changes", "RN_ADD.html#autotoc_md6", null ]
      ] ],
      [ "Resource Changes", "RN_ADD.html#RN_ADD_RSRC", null ],
      [ "Clock Changes", "RN_ADD.html#RN_ADD_CLOCK", null ],
      [ "Control Changes", "RN_ADD.html#RN_ADD_CONTROL", null ],
      [ "Board Interface Changes", "RN_ADD.html#RN_ADD_BOARD", null ]
    ] ],
    [ "Disclaimer", "DISCLAIMER.html", null ]
  ] ]
];

var NAVTREEINDEX =
[
"DISCLAIMER.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';